package custom;

import java.awt.Color;
import java.util.ArrayList;

import com.JJEngine.objects.PhysObject;
import com.JJEngine.objects.Point;
import com.JJEngine.objects.Vector;


public class VoronoiNode extends PhysObject{
	private Color color;
	
	public VoronoiNode(){
		super(new Point(0,0,0), new Vector(0,0,0), new Vector(0,0,0), new ArrayList<Vector>(), 1, "tfhnu");
		position = new Point(0,0,0);
		color = new Color(255,255,255);
		Main.world.add(this);
		Main.world.getPhysics().applyMotion(this);
	}
	
	public VoronoiNode(Point position, Color color){
		super(position, new Vector(0,0,0), new Vector(0,0,0), new ArrayList<Vector>(), 1, "tfhnu");
		this.color = color;
		Main.world.add(this);
		Main.world.getPhysics().applyMotion(this);
	}
	public VoronoiNode(Point position, Color color, Vector drift){
		super(position, new Vector(0,0,0), new Vector(0,0,0), new ArrayList<Vector>(), 1, "tfhnu");
		this.color = color;
		Main.world.add(this);
		Main.world.getPhysics().applyMotion(this);
		muK = 0f;
	}
	
	public Point getPos(){
		return position;
	}
	public Vector getVec(){
		return velocity;
	}
	public void setPos(Point p){
		this.position = p;
	}
	public void setVec(Vector v){
		this.velocity = v;
	}
	public void setColor(Color c){
		this.color = c;
	}
	public Color getColor(){
		return color;
	}

	@Override
	public void collision(PhysObject obj1, PhysObject obj2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void tick() {
		if(position.x < 0){
			position.x = 1000;
		}
		if(position.x > 1000){
			position.x = 0;
		}
		if(position.y < 0 | position.y > 500){
			if(position.x < 500){
				position.x += 500;
			} else {
				position.x -=500;
			}
			velocity.y *= -1;
		}
	}
}
