package custom;

import java.awt.Color;

import com.JJEngine.main.Engine;
import com.JJEngine.main.MainStructure;
import com.JJEngine.objects.Point;
import com.JJEngine.objects.Vector;
import com.JJEngine.scene.World;

public class Main extends MainStructure {
	
	static World world = new World();
	Team rome;
	Team gaul;
	public static void main(String[] args) {
		Engine.start(new Main());
	}

	public Main() {
		setSize(1000, 500);
		setName("Engine test");
		BORDERS = false;
	}

	public void init() {
		worlds.add(world);
		world.add(new Map());
		rome = new Team("Rome", new Color(200,0,0));
		gaul = new Team("Gaul", new Color(0,100,0));
		world.add(new Troop(new Point(25,-10,0), new Vector(), rome));
		world.add(new Troop(new Point(-25,10,0), new Vector(), gaul));
		world.start();
	}

	public void buttonAction(String name) {

	}

	public void mouseWheelUp() {
		if(Engine.getZoom() <10)
			Engine.setZoom(Engine.getZoom() * 1.1);
	}

	public void mouseWheelDown() {
		if(Engine.getZoom() >1)
			Engine.setZoom(Engine.getZoom() / 1.1);
	}

}
