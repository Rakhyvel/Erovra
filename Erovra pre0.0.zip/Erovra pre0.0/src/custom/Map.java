package custom;

import java.awt.Color;
import java.util.ArrayList;

import com.JJEngine.gui.Align;
import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;
import com.JJEngine.objects.Vector;
import com.JJEngine.scene.Image2D;
import com.JJEngine.scene.Model2D;

public class Map extends Model2D {

	public static int[] temp = new int[1000 * 500];
	public static ArrayList<VoronoiNode> voronoiNodes = new ArrayList<VoronoiNode>();
	Image2D img = new Image2D(temp, new Point(0, 1, 0), 1000, 500, Align.center);

	public Map() {
		super(new Point(0, 0, 0), 1000, 500, Color.BLACK, true, Align.center);
		generate();
	}

	public void generate() {
		// This is the seed for the land gen
		Engine.getRand().setSeed(1);

		// Create 12 large continents, these will determine the higher order of
		// the chaos

		for (int i = 0; i < 12; i++) {
			voronoiNodes.add(new VoronoiNode(new Point(Engine.getRand().nextInt(1000), Engine.getRand().nextInt(500), 0), new Color(i * 21, i * 21, i * 21), new Vector(Engine.getRand().nextInt(i * 2 + 1) - i, Engine.getRand().nextInt(i * 2 + 1) - i, 0)));
		}

		// Randomly fill in 200 other subcontinents, these will give the order
		// some randomness
		for (int i = 0; i < 400; i++) {
			int x = Engine.getRand().nextInt(1000), y = Engine.getRand().nextInt(500);
			double smallestDistance = 1000000;
			int smallestId = 0;
			double tempDistance = 0;
			int tempId = 0;
			for (int i2 = 0; i2 < voronoiNodes.size(); i2++) {
				double contY = voronoiNodes.get(i2).getPos().y, contX = voronoiNodes.get(i2).getPos().x;
				tempDistance = Math.pow(contY - y, 2) + Math.pow(contX - x, 2);
				if (tempDistance < smallestDistance) {
					smallestDistance = tempDistance;
					tempId = smallestId;
					smallestId = i2;
				}
			}
			int close = voronoiNodes.get(smallestId).getColor().getBlue();
			int far = voronoiNodes.get(tempId).getColor().getBlue();

			int val = (int) (close + far) / 2;
			if (val > 255) {
				val = 255;
			}
			if ((voronoiNodes.get(smallestId).getColor().getBlue() >= 128 && voronoiNodes.get(tempId).getColor().getBlue() < 128) | (voronoiNodes.get(smallestId).getColor().getBlue() < 128 && voronoiNodes.get(tempId).getColor().getBlue() >= 128)) {
				voronoiNodes.add(new VoronoiNode(new Point(x, y, 0), new Color(val, val, val), voronoiNodes.get(smallestId).getVec()));
			} else {
				i--;
			}
		}
		setupImg();
	}

	public void setupImg() {

	}

	public void tick() {}

	@Override
	public void render() {
		for (int i = 0; i < 500000; i += 1) {
			int x = (i - (int) (i / 1000) * 1000);
			int y = (int) (i / 1000);
			double smallestDistance = 1000000 * Engine.getZoom();
			int smallestId = 0;
			for (int i2 = 0; i2 < voronoiNodes.size(); i2++) {
				double contY = voronoiNodes.get(i2).getPos().y * Engine.getZoom() - (250) * (Engine.getZoom() - 1), contX = voronoiNodes.get(i2).getPos().x * Engine.getZoom() - (500) * (Engine.getZoom() - 1);
				double tempDistance = (contX - x) * (contX - x)+ (contY - y)* (contY - y);
				if (tempDistance < smallestDistance) {
					smallestDistance = tempDistance;
					smallestId = i2;
				}
			}

			if (voronoiNodes.get(smallestId).getColor().getBlue() >= 128) {
				temp[i] = (int)(50+(-Math.abs((y/Engine.getZoom()-250/Engine.getZoom())/2)+125)/.8333) << 16 | (int)(150+(-Math.abs((y/Engine.getZoom()-250/Engine.getZoom())/2)+125)/2.5) << 8 | (int)(50+(-Math.abs((y/Engine.getZoom()-250/Engine.getZoom())/2)+125)/2.5) | 255 << 24;
			} else {
				temp[i] = 40 << 16 | 120 << 8 | 200 | 255 << 24;
			}
		}
		img.setPixels(temp);
		img.render();
	}

}
