package custom;

import java.awt.Color;
import java.util.ArrayList;

import com.JJEngine.gui.Align;
import com.JJEngine.main.Engine;
import com.JJEngine.objects.PhysObject;
import com.JJEngine.objects.Point;
import com.JJEngine.objects.Vector;
import com.JJEngine.scene.Rect2D;


public class Troop extends PhysObject{
	int food = 108000;
	float morale;
	Point target = new Point();
	Rect2D slave;
	Rect2D highlight;
	boolean selected = false;
	Team team;
	
	public Troop(Point position, Vector velocity, Team team) {
		super(position, velocity, new Vector(0,0,0), new ArrayList<Vector>(), 5000f, 6,3, team.name);
		this.team = team;
		highlight = new Rect2D(new Point(0,0,0), 64, 34, new Color(200,200,200), true, Align.center);
		slave = new Rect2D(new Point(0,0,0), 60, 30, team.color, true, Align.center);
		Main.world.add(highlight);
		Main.world.add(slave);
		Main.world.getPhysics().applyMotion(this);
		Main.world.getPhysics().applyAABBCollision(this);
		muK=0;
	}

	@Override
	public void collision(PhysObject obj1, PhysObject obj2) {
		if(!obj1.name.equals(obj2)){
			obj2.mass -= 166*mass/obj2.mass;
			target = null;
		}
	}

	@Override
	public void tick() {
		Main.world.getPhysics().AABBCollision(this);
		slave.position = position.multScalar(Engine.getZoom());
		highlight.position = position.multScalar(Engine.getZoom());
		food--;
		if(target != null){
			if(Math.abs(position.x-target.x) < .1 && Math.abs(position.y-target.y) < .1){
				position = target;
				velocity = new Vector(0,0,0);
			} else {
				velocity = target.subVec(position).normalizeThis().mult(.1);
			}
		} else {
			velocity = new Vector(0,0,0);
		}
		if(mass <= 0){
			Main.world.getPhysics().remove(this);
			Main.world.remove(this);
			Main.world.remove(slave);
		}
		if(Engine.getMouseLeftDown() && name == "Rome"){
			if(slave.touchingMouseAABB()){
				selected = true;
			} else {
				if(selected)
					target = new Point(Align.getX(Engine.getMouseX() - Engine.getWidth(), Align.center)/Engine.getZoom(), Align.getY(Engine.getMouseY(), Align.center)/Engine.getZoom(),0);
				selected = false;
			}
		}
		if(selected){
			highlight.setOpacity(1f);
		} else {
			highlight.setOpacity(0f);
		}
	}
}
