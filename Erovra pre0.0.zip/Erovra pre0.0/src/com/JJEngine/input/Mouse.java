package com.JJEngine.input;

import java.awt.MouseInfo;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import com.JJEngine.main.Engine;

public class Mouse extends MouseAdapter {
	private boolean mouseLeftDown = false;
	private boolean mouseRightDown = false;

	public void mousePressed(MouseEvent m) {
		// When mouse is pressed, set mouseDown to true
		if(m.getButton() == MouseEvent.BUTTON1)
			mouseLeftDown = true;
		if(m.getButton() == MouseEvent.BUTTON3)
			mouseRightDown = true;
	}

	public void mouseReleased(MouseEvent m) {
		// When the mouse was pressed and is now released, set mouseDown to
		// false
		if(m.getButton() == MouseEvent.BUTTON1)
			mouseLeftDown = false;
		if(m.getButton() == MouseEvent.BUTTON3)
			mouseRightDown = false;
	}

	public int getX() {
		return (int) MouseInfo.getPointerInfo().getLocation().getX()-Engine.getFrameX();
	}

	public int getY() {
		return (int) MouseInfo.getPointerInfo().getLocation().getY()-Engine.getFrameY();
	}
	
	public boolean getMouseLeftDown(){
		return mouseLeftDown;
	}
	public boolean getMouseRightDown(){
		return mouseRightDown;
	}
}
