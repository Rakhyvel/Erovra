package com.JJEngine.input;

import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import com.JJEngine.main.Engine;


public class MouseWheel implements MouseWheelListener {
	private static int notches = 0;

	public void mouseWheelMoved(MouseWheelEvent e) {
		notches = e.getWheelRotation();
		if (notches < 0) {
			// Mouse wheel moved up
			Engine.mouseWheelUp();
		} else {
			// Mouse wheel moved up
			Engine.mouseWheelDown();
		}

	}
}