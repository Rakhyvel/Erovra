package com.JJEngine.input;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import com.JJEngine.main.Engine;

public class Keyboard extends KeyAdapter {

	String letter = "";
	
	public void keyPressed(KeyEvent e) {
		setKey(e.getKeyCode(),true);
		letter = String.valueOf(e.getKeyChar());
	}

	public void keyReleased(KeyEvent e) {
		setKey(e.getKeyCode(),false);
		letter = "";
	}
	
	public void setKey(int keyCode, boolean pressed){
		if(keyCode == KeyEvent.VK_UP){
			up.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_DOWN){
			down.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_LEFT){
			left.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_RIGHT){
			right.setPressed(pressed);
		}
		
		if(keyCode == KeyEvent.VK_Q){
			q.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_E){
			e.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_R){
			r.setPressed(pressed);
		}
		
		if(keyCode == KeyEvent.VK_W){
			w.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_S){
			s.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_A){
			a.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_D){
			d.setPressed(pressed);
		}
		
		if(keyCode == KeyEvent.VK_CONTROL){
			control.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_SHIFT){
			shift.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_SPACE){
			space.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_ESCAPE){
			esc.setPressed(pressed);
		}
		
		if(keyCode == KeyEvent.VK_Z){
			z.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_X){
			x.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_C){
			c.setPressed(pressed);
		}
		if(keyCode == KeyEvent.VK_V){
			v.setPressed(pressed);
		}
	}
	
	public Key up = new Key();
	public Key down = new Key();
	public Key left = new Key();
	public Key right = new Key();
	
	public Key q = new Key();
	public Key e = new Key();
	public Key r = new Key();
	
	public Key w = new Key();
	public Key s = new Key();
	public Key a = new Key();
	public Key d = new Key();
	
	public Key control = new Key();
	public Key shift = new Key();
	public Key space = new Key();
	public Key esc = new Key();

	public Key z = new Key();
	public Key x = new Key();
	public Key c = new Key();
	public Key v = new Key();

	public class Key {

		private boolean pressed = false;

		public boolean isPressed() {
			return pressed;
		}

		public void setPressed(boolean pressed) {
			this.pressed = pressed;
		}
	}
	
	public String getLetter(){
		return letter;
	}
}
