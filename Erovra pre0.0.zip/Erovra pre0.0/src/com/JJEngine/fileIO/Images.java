package com.JJEngine.fileIO;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Images {

	private static BufferedImage image;

	public static BufferedImage loadImage(String path) {
		// takes a path to the image
		try {
			image = ImageIO.read(new FileInputStream(path));
			// get the image
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		// return the image
		return image;
	}

	public static int[] toArray(BufferedImage img) {
		return img.getRGB(0, 0, img.getWidth(), img.getHeight(), null, 0, img.getWidth());
	}
	
}
