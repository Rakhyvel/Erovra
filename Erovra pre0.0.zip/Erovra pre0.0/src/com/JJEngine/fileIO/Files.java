package com.JJEngine.fileIO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

public class Files {
	public static void write(String name, String extension, String content,
			String path) {
		// Takes the name, extension, and path and write 'content' to a new file
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(path + "/" + name + "." + extension),
				"utf-8"))) {
			writer.write(content);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String read(String path) {
		try {
			// FileReader reads text files in the default encoding.
			System.out.println(path);
			FileReader fileReader = new FileReader(path);

			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			while (bufferedReader.ready()) {
				// Returns the content in the file
				return bufferedReader.readLine();
			}
			bufferedReader.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Could not find file at '" + path + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + path + "'");
		}
		return "";
	}
}
