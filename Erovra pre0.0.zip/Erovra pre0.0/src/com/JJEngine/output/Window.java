package com.JJEngine.output;

import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.JJEngine.main.Engine;

public class Window extends JPanel {

	private static final long serialVersionUID = 1L;
	private JFrame frame = new JFrame();
	private static JPanel gamePanel = new JPanel();
	public static Container window;

	public Window() {
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setUndecorated(!Engine.getBorders());
		frame.setVisible(true);
		// Custom options
		frame.setSize(Engine.getWidth(), Engine.getHeight());
		frame.setTitle(Engine.getName());
		frame.setResizable(Engine.getResizeable());

		frame.add(this);
		frame.add(Engine.getRender());

		// Built options
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setFocusable(true);
		// frame.setAlwaysOnTop(true);
	}

	public int getFrameX() {
		return frame.getX();
	}

	public int getFrameY() {
		return frame.getY();
	}
}
