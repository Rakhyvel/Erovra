package com.JJEngine.output;

import java.io.File;
import java.util.ArrayList;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

import com.JJEngine.main.Engine;

public class Sound extends Thread {
	private static ArrayList<String> tracks = new ArrayList<String>();
	private static float volume = 1f;

	public void play(String name) {
		// Takes sound filename ('name') and starts a new thread
		tracks.add(name+Engine.getRand().nextInt(9)+""+Engine.getRand().nextInt(9)+""+Engine.getRand().nextInt(9));
		(new Sound()).start();
	}

	public void silence(String name) {
		// Takes filename 'name' and removes it from track array
		if (tracks.size() > -1) {
			if (getPos(name) > -1) {
				tracks.remove(getPos(name));
			}
		}
	}
	
	public void silenceAll(){
		for(int i = 0; i < tracks.size(); i++){
			tracks.remove(i);
		}
	}

	@Override
	public void run() {
		// Finds the file, plays the clip
		int pos = tracks.size() - 1;
		String name = tracks.get(pos);
		try {
			File file = new File("src/custom/Res/" + name.substring(0, name.length()-3) + ".wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(file));
			clip.start();
			while (tracks.contains(name)) {
				if (clip.getMicrosecondPosition() == clip
						.getMicrosecondLength()) {
					silence(name);
				}
			}
			clip.stop();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public boolean isPlaying() {
		return !tracks.isEmpty();
	}

	public int getPos(String name) {
		return tracks.indexOf(name);
	}
	public void setVolume(float v){
		volume = v;
	}

	public float getVolume() {
		return volume;
	}
}
