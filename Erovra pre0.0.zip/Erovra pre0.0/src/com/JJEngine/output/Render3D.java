package com.JJEngine.output;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.JJEngine.Geometry.Tri;
import com.JJEngine.main.Engine;
import com.JJEngine.objects.Point;
import com.JJEngine.objects.Vector;
import com.JJEngine.scene.Camera;
import com.JJEngine.scene.Model3D;

public class Render3D {
	private Camera camera;
	public Render3D(double fieldOfView){
		camera = new Camera(new Point(100,200,100),new Point(0,0,0),45);
	}
	public void render3d(BufferedImage img){
		camera.compute();
		for(int i = 0; i<Engine.getCurrentWorld().getObject3D().size(); i++){
			Model3D temp = Engine.getCurrentWorld().getObject3D().get(i);
			for(int i2 = 0; i2<Engine.getCurrentWorld().getObject3D().get(i).faces.size(); i2++){
				Tri face = transform(temp, scale(temp, temp.faces.get(i2)));
				if(face.normal.dot(face.p0.subVec(camera.eye))>0){
					Graphics g2d= img.getGraphics();
					g2d.fillPolygon(new int[]{(int)Engine.rawToCenterX(createRayX(face.p0)),(int)Engine.rawToCenterX(createRayX(face.p1)),(int)Engine.rawToCenterX(createRayX(face.p2))}, new int[]{(int)Engine.rawToCenterY(createRayY(face.p0)),(int)Engine.rawToCenterY(createRayY(face.p1)),(int)Engine.rawToCenterY(createRayY(face.p2))}, 3);
					g2d.dispose();
				}
			}
		}
	}
	public double createRayX(Point point){
		Vector v = new Vector(point.subVec(camera.eye));
		Point s = camera.eye.add(camera.lookat.subVec(camera.eye).normalizeThis().mult(camera.distance));
		Vector w = new Vector(s.subVec(camera.eye));
		double k = w.dot(camera.w)/v.dot(camera.w);
		Point i = camera.eye.add(v.mult(k));
		return i.dot(camera.u);
	}
	public double createRayY(Point point){
		Vector v = new Vector(point.subVec(camera.eye));
		Point s = camera.eye.add(camera.lookat.subVec(camera.eye).normalizeThis().mult(camera.distance));
		Vector w = new Vector(s.subVec(camera.eye));
		double k = w.dot(camera.w)/v.dot(camera.w);
		Point i = camera.eye.add(v.mult(k));
		return i.dot(camera.v);
	}
	public Tri scale(Model3D model3D, Tri face){
		return new Tri(face.p0.mult(model3D.scale),face.p1.mult(model3D.scale),face.p2.mult(model3D.scale),face.red,face.green,face.blue);
	}
	public Tri transform(Model3D model3D, Tri face){
		return new Tri(face.p0.add(model3D.pos),face.p1.add(model3D.pos),face.p2.add(model3D.pos),face.red,face.green,face.blue);
	}
}