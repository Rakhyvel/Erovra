package com.JJEngine.output;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import com.JJEngine.main.Engine;

public class Render2D extends Canvas {

	private static final long serialVersionUID = 6736297189346547853L;
	Graphics g;
	static BufferedImage buffer = new BufferedImage(Engine.getWidth(), Engine.getHeight(), BufferedImage.TYPE_INT_RGB);
	private static int[] pixels = ((DataBufferInt) buffer.getRaster().getDataBuffer()).getData();
	private static double zoom = 1;
	BufferStrategy bs;
	private static double xOffset, yOffset;

	// GRAPHICS

	public Render2D() {
		this.addMouseListener(Engine.getMouse());
		this.addMouseWheelListener(Engine.getMouseWheel());
		this.addKeyListener(Engine.getKeyboard());
	}

	public void render() {
		bs = this.getBufferStrategy();
		if (bs == null) {
			createBufferStrategy(2);
			return;
		}
		g = bs.getDrawGraphics();

		// refresh the screen
		if (Engine.getRefresh()) refresh();

		// 3d rendering is outsourced HERE
		if (!Engine.getCurrentWorld().getObject3D().isEmpty()) Engine.render3D(buffer);

		// 2d rendering is done HERE
		if (!Engine.getCurrentWorld().getObject2D().isEmpty()) {
			for (int i = 0; i < Engine.getCurrentWorld().getObject2D().size(); i++) {
				if(Engine.getCurrentWorld().getObject2D().get(i) != null)
					Engine.getCurrentWorld().getObject2D().get(i).render();
			}
		}
		// final image is sent to screen
		g.drawImage(buffer, 0, 0, null);

		bs.show();
		g.dispose();
	}
	public void drawLine(int x1, int x2, int y1, int y2, int color){
		double dx = x2-x1;
		double dy = y2-y1;
		if(dy >= dx){
			if(x2 > x1){
				for(int x = x1; x < x2; x++){
					int y = (int)(y1 + dy*(x - x1) / dx);
					if(y > 0 && y < Engine.getHeight()){
						pixels[y*Engine.getWidth() + x] = color;
					}
				}
			} else {
				for(int x = x2; x < x1; x++){
					int y = (int)(y1 + dy*(x - x1) / dx);
					if(y > 0 && y < Engine.getHeight()){
						pixels[y*Engine.getWidth() + x] = color;
					}
				}
			}
		} else {
			if(y2 > y1){
				for(int y = y1; y < y2; y++){
					int x = (int)(x1 + dx*(y - y1) / dy);
					if(y > 0 && y < Engine.getHeight()){
						pixels[y*Engine.getWidth() + x] = color;
					}
				}
			} else {
				for(int y = y2; y < y1; y++){
					int x = (int)(x1 + dx*(y - y1) / dy);
					if(y > 0 && y < Engine.getHeight()){
						pixels[y*Engine.getWidth() + x] = color;
					}
				}
			}
		}
	}
	public void drawImage(int x, int y, int width, int[] image, float opacity) {
		if (x < Engine.getWidth() && x > -width && y > -(image.length / width)) {
			//Checks if any part of the image is actually on screen
			int m = (y * Engine.getWidth()) + x + width;
			//m: index for screen, starts at top left corner of image.
			int n = Engine.getWidth() - width;
			//n: how many screenwise-pixels are in between the end of a scanline and the begining of the next scanline
			int c = 0;
			//c: current row of image, starts at 0
			int a = m / Engine.getWidth();
			//a: row of current scanline, pixelwise
			int b = m;
			for (double i = 0; i < image.length; i++, m++) {
				c = (int)(i % width);
				if (c == 0) {
					m += n;
					b = m;
				}
				a = m / Engine.getWidth();
				if (m > 0 && m < pixels.length) {
					//checks to see that scanline is within screen, verticalwise
					if (x >= 0 && a == b / Engine.getWidth()) {
						//checks to see that image sta
						int img = image[(int)i];
						if(img != 0){
							pixels[m] = getColor(img, pixels[m], opacity, 1f);
						}
					}
					if (x < 0 && a > (b-width/2) / Engine.getWidth()) {
						//checks to see if the row of the current scanline is less than or equal to 
						int img = image[(int)i];
						if(img != 0){
							pixels[m] = getColor(img, pixels[m], opacity, 1f);
						}
					}
				}
			}
		}
	}
	
	public void drawImageBW(int x, int y, int width, int[] image, float opacity) {
		if (x < Engine.getWidth() && x > -width && y > -(image.length / width)) {
			//Checks if any part of the image is actually on screen
			int m = (y * Engine.getWidth()) + x + width;
			//m: index for screen, starts at top left corner of image.
			int n = Engine.getWidth() - width;
			//n: how many screenwise-pixels are in between the end of a scanline and the begining of the next scanline
			int c = 0;
			//c: current row of image, starts at 0
			int a = m / Engine.getWidth();
			//a: row of current scanline, pixelwise
			int b = m;
			for (double i = 0; i < image.length; i++, m++) {
				c = (int)(i % width);
				if (c == 0) {
					m += n;
					b = m;
				}
				a = m / Engine.getWidth();
				if (m > 0 && m < pixels.length) {
					//checks to see that scanline is within screen, verticalwise
					if (x >= 0 && a == b / Engine.getWidth()) {
						//checks to see that image sta
						int img = image[(int)i];
						if(img != 0){
							pixels[m] = getColorBW(img, pixels[m], opacity);
						}
					}
					if (x < 0 && a > (b-width/2) / Engine.getWidth()) {
						//checks to see if the row of the current scanline is less than or equal to 
						int img = image[(int)i];
						if(img != 0){
							pixels[m] = getColorBW(img, pixels[m], opacity);
						}
					}
				}
			}
		}
	}
	public void drawImage(int x, int y, int width, int[] image, float opacity, int tint) {
		if (x < Engine.getWidth() && x > -width && y > -(image.length / width)) {
			//Checks if any part of the image is actually on screen
			int m = (y * Engine.getWidth()) + x;
			//m: index for screen, starts at top left corner of image.
			int n = Engine.getWidth() - width;
			//n: how many screenwise-pixels are in between the end of a scanline and the begining of the next scanline
			int c = 0;
			//c: current row of image, starts at 0
			int a = m / Engine.getWidth();
			//a: row of current scanline, pixelwise
			int b = m;
			for (double i = 0; i < image.length; i++, m++) {
				c = (int)(i % width);
				if (c == 0) {
					m += n;
					b = m;
				}
				a = m / Engine.getWidth();
				if (m > 0 && m < pixels.length) {
					//checks to see that scanline is within screen, verticalwise
					if (x >= 0 && a == b / Engine.getWidth()) {
						//checks to see that image sta
						int img = image[(int)i];
						pixels[m] = getColor(getColorMask(img, tint, opacity), pixels[m], opacity, 1f);
						
					}
					if (x < 0 && a > (b-width/2) / Engine.getWidth()) {
						//checks to see if the row of the current scanline is less than or equal to 
						int img = image[(int)i];
						pixels[m] = getColor(getColorMask(img, tint, opacity), pixels[m], opacity,1f);
						
					}
				}
			}
		}
	}
	public void drawImageBright(int x, int y, int width, int[] image, float opacity, float brightness) {
		if (x < Engine.getWidth() && x > -width && y > -(image.length / width)) {
			//Checks if any part of the image is actually on screen
			int m = (y * Engine.getWidth()) + x + width;
			//m: index for screen, starts at top left corner of image.
			int n = Engine.getWidth() - width;
			//n: how many screenwise-pixels are in between the end of a scanline and the begining of the next scanline
			int c = 0;
			//c: current row of image, starts at 0
			int a = m / Engine.getWidth();
			//a: row of current scanline, pixelwise
			int b = m;
			for (double i = 0; i < image.length; i++, m++) {
				c = (int)(i % width);
				if (c == 0) {
					m += n;
					b = m;
				}
				a = m / Engine.getWidth();
				if (m > 0 && m < pixels.length) {
					//checks to see that scanline is within screen, verticalwise
					if (x >= 0 && a == b / Engine.getWidth()) {
						//checks to see that image sta
						int img = image[(int)i];
						pixels[m] = getColorBright(img, pixels[m], opacity, brightness);
						
					}
					if (x < 0 && a > (b-width/2) / Engine.getWidth()) {
						//checks to see if the row of the current scanline is less than or equal to 
						int img = image[(int)i];
						pixels[m] = getColorBright(img, pixels[m], opacity, brightness);
						
					}
				}
			}
		}
	}
	
	public void drawRect(int x, int y, int width, int height, int color, float opacity){
		if (x < Engine.getWidth() && x > -width && y > -(height)) {
			int m = (y * Engine.getWidth()) + x + width;
			int n = Engine.getWidth() - width;
			int c = 0;
			int a = m / Engine.getWidth();
			int b = m;
			for (double i = 0; i < width*height; i++, m++) {
				c = (int)(i % width);
				if (c == 0) {
					m += n;
					b = m;
				}
				a = m / Engine.getWidth();
				if (m > 0 && m < pixels.length) {
					if (x >= 0 && a == b / Engine.getWidth()) {
						pixels[m] = getColor(color, pixels[m], opacity, 1f);
					}
					if (x < 0 && a > (b - width/2) / Engine.getWidth()) {
						pixels[m] = getColor(color, pixels[m], opacity, 1f);
					}
				}
			}
		}
	}
	
	public int getColor(int img, int img2, float opacity, float brightness){
		double red = (img >>16)&255;
		double red2 = (img2 >>16)&255;
		double green = (img >> 8)&255;
		double green2 = (img2 >> 8)&255;
		double blue = img & 255;
		double blue2 = img2 & 255;
		double alpha = ((img >>24)&255)*opacity;
		return ((int)((red*brightness)*(alpha/255)+red2*(1-(alpha/255)))<<16) | (int)((green*brightness)*(alpha/255)+green2*(1-(alpha/255)))<<8 | (int)((blue*brightness)*(alpha/255)+blue2*(1-(alpha/255)));
	}
	public int getColorBright(int img, int img2, float opacity, float brightness){
		double red = (img >>16)&255;
		double red2 = (img2 >>16)&255;
		double green = (img >> 8)&255;
		double green2 = (img2 >> 8)&255;
		double blue = img & 255;
		double blue2 = img2 & 255;
		double alpha = ((img >>24)&255)*opacity;
		double bn = Math.max(red, green);
		double br = (.5*(Math.max(red, green) + Math.max(blue, green)) + blue) / 2;
		return ((int)((bn*brightness*(brightness))*(alpha/255)+red2*(1-(alpha/255)))<<16) | (int)((br*brightness*(brightness))*(alpha/255)+green2*(1-(alpha/255)))<<8 | (int)((blue*brightness)*(alpha/255)+blue2*(1-(alpha/255)));
	}
	
	public int getColorBlind(int img, int img2, float opacity){
		double red = (img >>16)&255;
		double red2 = (img2 >>16)&255;
		double green = (img >> 8)&255;
		double green2 = (img2 >> 8)&255;
		double blue = img & 255;
		double blue2 = img2 & 255;
		double alpha = ((img >>24)&255)*opacity;
		double br = .5*(Math.max(red, green) + Math.max(blue, green));
		double bn = Math.max(red, green);
		return ((int)(bn*(alpha/255)+red2*(1-(alpha/255)))<<16) | (int)(((br+blue)/2)*(alpha/255)+green2*(1-(alpha/255)))<<8 | (int)((blue)*(alpha/255)+blue2*(1-(alpha/255)));
	}
	
	public int getColorBW(int img, int img2, float opacity){
		double red = (img >>16)&255;
		double red2 = (img2 >>16)&255;
		double green = (img >> 8)&255;
		double green2 = (img2 >> 8)&255;
		double blue = img & 255;
		double blue2 = img2 & 255;
		double alpha = ((img >>24)&255)*opacity;
		double br = (Math.sqrt(red*blue)/2)+(green/2);
		return ((int)(br*(alpha/255)+red2*(1-(alpha/255)))<<16) | (int)(br*(alpha/255)+green2*(1-(alpha/255)))<<8 | (int)(br*(alpha/255)+blue2*(1-(alpha/255)));
	}
	
	public int getColorMask(int img, int tint, float opacity){
		double red2 = (tint >>16)&255;
		double green2 = (tint >> 8)&255;
		double blue2 = tint & 255;
		double alpha = ((img >> 24)&255);
		return ((int)alpha<<24) | ((int)(((alpha/255))*red2)<<16) | ((int)(((alpha/255))*green2)<<8) | (int)(((alpha/255))*blue2);
	}

	public void refresh() {
		for (int i = 0; i < pixels.length; i++) {
			pixels[i] = 255<<24;
		}
	}

	public double getZoom() {
		return zoom;
	}

	public void setZoom(double z) {
		zoom = z;
	}

	public double getXOffset() {
		return xOffset;
	}

	public double getYOffset() {
		return yOffset;
	}
}