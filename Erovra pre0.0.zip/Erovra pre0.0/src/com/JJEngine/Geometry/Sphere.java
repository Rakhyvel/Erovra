package com.JJEngine.Geometry;

import com.JJEngine.objects.Point;
import com.JJEngine.objects.Ray;

public class Sphere extends GeometricObject{
	public Point center;
	double radius;
	
	public Sphere(Point center, double radius){
		this.center=new Point(center);
		this.radius=radius;
	}
	public double hit(Ray ray){
		double a=ray.vector.dot(ray.vector);
		double b=2*ray.origin.sub(center).dot(ray.vector);
		double c=ray.origin.sub(center).dot(ray.origin.sub(center))-radius*radius;
		double discriminat=b*b-4*a*c;
		
		if(discriminat<0.0){
			return 0.0;
			// Did not hit sphere
		}else{
			double t=(-b - Math.sqrt(discriminat))/(2*a);
			if(t<10E9){
				return t;
			}else{
				return 0.0;
			}
		}
	}
}
