package com.JJEngine.Geometry;

import com.JJEngine.objects.Point;
import com.JJEngine.objects.Ray;
import com.JJEngine.objects.Vector;

public class Tri extends GeometricObject{
	//A triangle's three vertices are always coPlanar. A triangle is defined by a plane, and three points on that plane
	public Point p0,p1,p2;
	public Vector normal;
	Vector v01;
	Vector v12;
	Vector v20;
	public double red;
	public double blue;
	public double green;
	public Tri (Point p0, Point p1, Point p2, Double red,  Double green, Double blue){
		this.p0=p0;
		this.p1=p1;
		this.p2=p2;
		//The normal is defined by the cross product(perpendicular vector) of the first two edges (since triangles are always coplanar)
		this.red=red;
		this.green=green;
		this.blue=blue;
		normal=this.getNormal();
	}
	public double hit(Ray ray){
		if(normal.dot(ray.vector)>=0){
			double t=p0.sub(ray.origin).dot(normal)/ray.vector.dot(normal);
			if(t>10E-9){		
				Point intersect = ray.vector.normalizeThis().mult(t).add(ray.origin);
				Vector v0i=p0.subVec(intersect);
				Vector v1i=p1.subVec(intersect);
				Vector v2i=p2.subVec(intersect);
				if((v01.cross(v0i).dot(normal)<0) == (v12.cross(v1i).dot(normal)<0)){
					if((v01.cross(v0i).dot(normal)<0) == (v20.cross(v2i).dot(normal)<0)){
						return t;
					}
				}			
			}
		}
		return 0;
	}
	public Vector getNormal(){
		v01=p0.subVec(p1);
		v12=p1.subVec(p2);
		return new Vector(v01.cross(v12));
	}
}
