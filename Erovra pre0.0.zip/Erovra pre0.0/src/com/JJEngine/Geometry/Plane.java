package com.JJEngine.Geometry;

import com.JJEngine.objects.Point;
import com.JJEngine.objects.Ray;
import com.JJEngine.objects.Vector;

public class Plane extends GeometricObject{
	// An infinite plane is defned by a point in space and a normal
	Point point;
	Vector normal;
	public Plane (Point point, Vector normal){
		this.point = new Point(point);
		this.normal = new Vector(normal);
	}
	public double hit(Ray ray){
		// The distance is the differnece of the ray and the origin, dot product with the normal over the distance dot producted with the normal
		double t=point.sub(ray.origin).dot(normal)/ray.vector.dot(normal);
		if(t>10E-9){
			return t;
		}
		return 0.0;
	}
}
