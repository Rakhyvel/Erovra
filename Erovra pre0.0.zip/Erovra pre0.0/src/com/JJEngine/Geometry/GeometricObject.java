package com.JJEngine.Geometry;

import com.JJEngine.objects.Ray;

public abstract class GeometricObject {
	public abstract double hit(Ray ray);
}
