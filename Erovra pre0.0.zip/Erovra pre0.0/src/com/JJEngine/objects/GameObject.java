package com.JJEngine.objects;

public abstract class GameObject {

	public Point position;

	public GameObject(Point position) {
		this.position = position;
	}

	public GameObject(GameObject g) {
		this.position = g.position;
	}

	public abstract void tick();
	
	public Point getPosition(){
		return position;
	}
	
	public void setPosition(Point p){
		this.position = p;
	}
	
	public double getX(){
		return position.x;
	}
	public double getY(){
		return position.y;
	}
	public double getZ(){
		return position.z;
	}
}
