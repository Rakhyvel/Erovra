package com.JJEngine.objects;

public class Point2D {
	// Creates a unique point in 2D space, usefull for antialiasing,2D graphics
	public double x,y;
	public Point2D(){
		x=0;
		y=0;
	}
	public Point2D(double x, double y){
		this.x=x;
		this.y=y;
	}
	public Point2D(Point2D p){
		x=p.x;
		y=p.y;
	}
}
