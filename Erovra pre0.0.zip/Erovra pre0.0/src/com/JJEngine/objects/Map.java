package com.JJEngine.objects;

import java.awt.Color;
import java.awt.image.BufferedImage;

import custom.Main;

public class Map {

	public int[] tiles;
	public int width;
	public int height;

	public Map(BufferedImage image) {
		width = image.getWidth();
		height = image.getHeight();
		tiles = new int[width * height];
		for (int i = 0; i < width * height; i++) {
			int y = (int) (i / width);
			int x = i - y * width;
			Color color = new Color(image.getRGB(x, y), true);
			tiles[i] = color.getBlue();
		}
	}

	public int getTile(int x, int y) {
		return tiles[y * width + x];
	}

	public boolean touchingIdBottom(int x, int y, int id) {
		return getTile((int) (x) / 64, (int) (y) / 64) == 0 || getTile((int) (x + 64) / 64, (int) (y) / 64) == 0;
	}

	public boolean touchingIdTop(int x, int y, int id) {
		return getTile((int) (x) / 64, (int) (y + 64) / 64) == 0 || getTile((int) (x + 64) / 64, (int) (y + 64) / 64) == 0;
	}

	public boolean touchingIdLeft(int x, int y, int id) {
		return getTile((int) (x) / 64, (int) (y) / 64) == 0 || getTile((int) (x) / 64, (int) (y + 64) / 64) == 0;
	}

	public boolean touchingIdRight(int x, int y, int id) {
		return getTile((int) (x + 64) / 64, (int) (y) / 64) == 0 || getTile((int) (x + 64) / 64, (int) (y + 64) / 64) == 0;
	}
}
