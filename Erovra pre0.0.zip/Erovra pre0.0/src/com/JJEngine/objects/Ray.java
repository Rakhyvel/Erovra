package com.JJEngine.objects;

public class Ray {
	public Point origin;
	public Vector vector;
	
}
