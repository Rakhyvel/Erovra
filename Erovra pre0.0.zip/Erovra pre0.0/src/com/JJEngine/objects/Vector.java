package com.JJEngine.objects;

public class Vector {

	// This is basically the same class as point, and you can use points as
	// vectors
	public double x, y, z;
	public static final Vector up = new Vector(0.000424, 1, 0.000726);

	public Vector() {
		x = 0;
		y = 0;
		z = 0;
	}

	public Vector(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public Vector(Vector v) {
		x = v.x;
		y = v.y;
		z = v.z;
	}

	public Vector add(Vector v) {
		return new Vector(x + v.x, y + v.y, z + v.z);
	}

	public Point add(Point v) {
		return new Point(x + v.x, y + v.y, z + v.z);
	}

	public Vector sub(Vector v) {
		return new Vector(x - v.x, y - v.y, z - v.z);
	}

	public Vector sub(Point v) {
		return new Vector(x - v.x, y - v.y, z - v.z);
	}

	public Vector mult(double scalar) {
		return new Vector(x * scalar, y * scalar, z * scalar);
	}

	public Vector div(double scalar) {
		return new Vector(x / scalar, y / scalar, z / scalar);
	}

	public double dot(Vector v) {
		// Projects one vector onto another, giving a scalar value
		return x * v.x + y * v.y + z * v.z;
	}

	public double dot(Point p) {
		// Projects one vector onto a point, giving a scalar value
		return x * p.x + y * p.y + z * p.z;
	}

	public Vector cross(Vector vector) {
		return new Vector(y * vector.z - vector.y * z, z * vector.x - x * vector.z, x * vector.y - vector.x * y);
	}

	public void normalize() {
		// This method takes a vector with components of any length and changes
		// all of them to be between 1 and 0 (Unit vectors)
		double magnitude = Math.sqrt(x * x + y * y + z * z);
		x /= magnitude;
		y /= magnitude;
		z /= magnitude;
	}

	public Vector normalizeThis() {
		// This method takes a vector with components of any length and changes
		// all of them to be between 1 and 0 (Unit vectors)
		double magnitude = Math.sqrt(x * x + y * y + z * z);
		double x1 = x, y1 = y, z1 = z;
		if (magnitude == 0) {
			return new Vector(0, 0, 0);
		} else {
			x1 /= magnitude;
			y1 /= magnitude;
			z1 /= magnitude;
		}
		return new Vector(x1, y1, z1);
	}

	public double magnitude() {
		return Math.sqrt(x * x + y * y + z * z);
	}

	public double angle(Vector vector) {
		return Math.toDegrees(Math.acos(dot(vector) / (magnitude() * vector.magnitude())));
	}

	public Vector multVec(Vector vector) {
		return new Vector(x * vector.x, y * vector.y, z * vector.z);
	}
}
