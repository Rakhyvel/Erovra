package com.JJEngine.objects;

import java.util.ArrayList;

import com.JJEngine.gui.Align;
import com.JJEngine.scene.World;

public class ParticleSystem {

	public World world;
	public Particle[] particles;
	public int size;
	public int particleCount = -1;

	public ParticleSystem() {
		size = 10;
		particles = new Particle[size];
	}

	public ParticleSystem(int size, World world) {
		this.size = size;
		particles = new Particle[size];
		this.world = world;
	}

	public void preFill(Particle particle, int i) {
		particles[i] = particle;
		particles[i].alive = false;
	}

	public void add(Particle p, Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double radius, String name, double life, Align align) {
		if (particleCount + 1 < size) {
			particleCount++;
			p.mutate(position, velocity, acceleration, forces, mass, radius, name, life, particleCount, this, align);
			particles[particleCount] = p;
			particles[particleCount].birth();

			world.getPhysics().applyMotion(particles[particleCount]);
			world.add(particles[particleCount]);
		}
	}
	public void add(Particle p) {
		if (particleCount + 1 < size) {
			particleCount++;
			particles[particleCount] = p;
			particles[particleCount].birth();

			world.getPhysics().applyMotion(particles[particleCount]);
			world.add(particles[particleCount]);
		}
	}

	public void fastAdd(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double radius, String name, double life, Align align) {
		if (particleCount + 1 < size) {
			particleCount++;
			particles[particleCount].mutate(position, velocity, acceleration, forces, mass, radius, name, life, particleCount, this, align);
			particles[particleCount].birth();
		}
	}
	public void particleDeath(int index) {
		particles[index] = null;
		particleCount--;
	}
	
	public void genocide(){
		for(int i = 0; i < particles.length; i++){
			if(particles[i] != null)
				particles[i].death();
		}
	}
}
