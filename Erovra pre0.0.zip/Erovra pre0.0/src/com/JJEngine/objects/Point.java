package com.JJEngine.objects;

public class Point {
	// X is left/right
	// Y is Up/down
	// Z is in and out of the screen
	public double x;
	public double y;
	public double z;
	
	public Point(){
		//Default constructor
		x=0;
		y=0;
		z=0;
	}
	public Point (double x, double y, double z){
		//Initialized constructor
		this.x=x;
		this.y=y;
		this.z=z;
	}
	public Point(Point point){
		//Copy-point constructor
		x=point.x;
		y=point.y;
		z=point.z;
	}
	public Point add(Point point){
		//Returns the sum of the object and the parameter object
		return new Point(x+point.x,y+point.y,z+point.z);
	}
	public Point add(Vector vector){
		return new Point(x+vector.x,y+vector.y,z+vector.z);
	}
	public Point sub(Point point){
		//Returns the difference of the object and the parameter object
		return new Point(x-point.x,y-point.y,z-point.z);
	}
	public Point sub(Vector vector){
		//Returns the difference of the object and the parameter object
		return new Point(x-vector.x,y-vector.y,z-vector.z);
	}
	public Vector subVec(Point point){
		//Returns the difference of the object and the parameter object
		return new Vector(x-point.x,y-point.y,z-point.z);
	}
	public Vector subVec(Vector vector){
		//Returns the difference of the object and the parameter object
		return new Vector(x-vector.x,y-vector.y,z-vector.z);
	}
	public Point mult(Point point){
		return new Point(x*point.x,y*point.y,z*point.z);
	}
	public Point mult(Vector vector){
		return new Point(x*vector.x,y*vector.y,z*vector.z);
	}
	public Point multScalar(double scalar){
		return new Point(x*scalar,y*scalar,z*scalar);
	}
	public Double dot(Point p){
		// Projects one point onto a point, giving a scalar value
		return x*p.x+y*p.y+z*p.z;
	}
	public Double dot(Vector v){
		// Projects one point onto a vector, giving a scalar value
		return x*v.x+y*v.y+z*v.z;
	}
	public Double getDistance(Point p){
		double xDif = x-p.x;
		double yDif = y-p.y;
		double zDif = z-p.z;
		return Math.sqrt(xDif*xDif+yDif*yDif+zDif*zDif);
	}
}
