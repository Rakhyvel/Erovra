package com.JJEngine.objects;

import java.util.ArrayList;


public class TempParticle extends Particle {

	public TempParticle(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double radius, String name, double life, int index, ParticleSystem ps) {
		super(position, velocity, acceleration, forces, mass, radius, name, life, index, ps);
		// TODO Auto-generated constructor stub
	}

	public TempParticle() {
		// TODO Auto-generated constructor stub
	}

	public TempParticle(ParticleSystem ps) {
		super(ps);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void collision(PhysObject obj1, PhysObject obj2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void birth() {
		// TODO Auto-generated method stub

	}

	@Override
	public void death() {
		// TODO Auto-generated method stub

	}

}
