package com.JJEngine.objects;

import java.util.ArrayList;

import com.JJEngine.main.Engine;
import com.JJEngine.scene.World;

public abstract class PhysObject extends GameObject {

	public Vector velocity;
	public Vector acceleration;
	public Vector momentum;
	public double mass = 1;
	public double radius;
	public double height = 0;
	public double width = 0;
	public ArrayList<Vector> forces = new ArrayList<Vector>();
	public String name = "?";
	public float muS = 1;
	public float muK = 1;

	public Vector netForces() {
		Vector net = new Vector();
		for (int i = 0; i < forces.size(); i++) {
			net = net.add(forces.get(i));
		}
		return net;
	}

	public PhysObject(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, String name) {
		super(position);
		this.velocity = velocity;
		this.acceleration = acceleration;
		this.momentum = new Vector(0, 0, 0);
		this.mass = mass;
		this.name = name;
	}

	public PhysObject(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double radius, String name) {
		super(position);
		this.velocity = velocity;
		this.acceleration = acceleration;
		this.momentum = new Vector(0, 0, 0);
		this.mass = mass;
		this.name = name;
		this.radius = radius;
	}

	public PhysObject(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double width, double height, String name) {
		super(position);
		this.velocity = velocity;
		this.acceleration = acceleration;
		this.momentum = new Vector(0, 0, 0);
		this.mass = mass;
		this.name = name;
		this.width = width;
		this.height = height;
	}

	public PhysObject(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double radius, double width, double height, String name) {
		super(position);
		this.velocity = velocity;
		this.acceleration = acceleration;
		this.momentum = new Vector(0, 0, 0);
		this.mass = mass;
		this.name = name;
		this.radius = radius;
		this.width = width;
		this.height = height;
	}

	public PhysObject(PhysObject p) {
		super(p);
		this.velocity = p.velocity;
		this.acceleration = p.acceleration;
		this.momentum = new Vector(0, 0, 0);
		this.forces = p.forces;
		this.mass = p.mass;
		this.radius = p.radius;
		this.width = p.width;
		this.height = p.height;
		this.name = p.name;
	}

	public static void windowCollision(PhysObject obj) {
		if (obj.position.x > (Engine.getWidth() / 2) + obj.radius) {
			obj.velocity.x = -obj.velocity.x;
			obj.position.x = Engine.getWidth() / 2;
		}
		if (obj.position.y > (Engine.getHeight() / 2) + obj.radius) {
			obj.velocity.y = -obj.velocity.y;
			obj.position.y = Engine.getHeight() / 2;
		}
		if (obj.position.x < (-Engine.getWidth() / 2) - obj.radius) {
			obj.velocity.x = -obj.velocity.x;
			obj.position.x = -Engine.getWidth() / 2;
		}
		if (obj.position.y < (-Engine.getHeight() / 2) - obj.radius) {
			obj.velocity.y = -obj.velocity.y;
			obj.position.y = -Engine.getHeight() / 2;
		}
	}

	public Vector getGravity() {
		return Engine.getGravity().mult(mass);
	}

	public Vector getFriction(float mu) {
		Vector veloCopy = velocity;
		double FrictionMag = 0;
		veloCopy.mult(-1);
		veloCopy = veloCopy.normalizeThis();
		veloCopy.mult(FrictionMag);
		return veloCopy;
	}

	public abstract void collision(PhysObject obj1, PhysObject obj2);

	public PhysObject applyMotion(World world) {
		world.getPhysics().applyMotion(this);
		return this;
	}

	public PhysObject applyOrbit(World world) {
		world.getPhysics().applyOrbit(this);
		return this;
	}

	public PhysObject applySphereCollision(World world) {
		world.getPhysics().applySphereCollision(this);
		return this;
	}

	public PhysObject applyAABBCollision(World world) {
		world.getPhysics().applyAABBCollision(this);
		return this;
	}
}
