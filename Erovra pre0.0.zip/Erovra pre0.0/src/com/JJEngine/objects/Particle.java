package com.JJEngine.objects;

import java.util.ArrayList;

import com.JJEngine.gui.Align;
import com.JJEngine.scene.Oval2D;
import com.JJEngine.scene.Rect2D;

public abstract class Particle extends PhysObject {

	public double startLife;
	public double life;
	protected Rect2D slave;
	protected ParticleSystem ps;
	public boolean alive;
	public int index;
	public Align align;

	public Particle(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double radius, String name, double life, int index, ParticleSystem ps) {
		super(position, velocity, acceleration, forces, mass, name);
		this.radius = radius;
		this.startLife = life;
		this.life = life;
		this.index = index;
		this.ps = ps;
		alive = true;
	}
	public Particle(){
		super(new Point(0, 0, 0), new Vector(0, 0, 0), new Vector(0, 0, 0), new ArrayList<Vector>(), 1, "null");
	}

	public Particle(ParticleSystem ps) {
		super(new Point(0, 0, 0), new Vector(0, 0, 0), new Vector(0, 0, 0), new ArrayList<Vector>(), 1, "null");
	}

	public void copy(Particle p) {
		this.position = p.position;

		this.velocity = p.velocity;
		this.acceleration = p.acceleration;
		this.forces = p.forces;
		this.mass = p.mass;
		this.radius = p.radius;
		this.name = p.name;
		this.radius = p.radius;

		this.life = p.life;
		this.startLife = p.startLife;
		this.slave = p.slave;
		this.alive = p.alive;
		slave= p.slave;
	}	
	public void mutate(Point position, Vector velocity, Vector acceleration, ArrayList<Vector> forces, double mass, double radius, String name, double life, int index, ParticleSystem ps, Align align) {

		this.position = position;

		this.velocity = velocity;
		this.acceleration = acceleration;
		this.forces = forces;
		this.mass = mass;
		this.radius = radius;
		this.name = name;
		this.radius = radius;

		this.life = life;
		this.startLife = life;
		this.ps = ps;
		this.align = align;
		this.index = index;
	}

	public void tick() {
		if (life > 0) {
			if(!alive){
				alive = true;
			} else {
				life -= (double) 1 / 60;
			}
		} else {
			if(alive){
				death();
				alive = false;
			}
		}
	}

	public abstract void collision(PhysObject obj1, PhysObject obj2);
	public abstract void birth();
	public abstract void death();
}
