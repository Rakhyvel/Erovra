package com.JJEngine.objects;

import com.JJEngine.main.Engine;
import com.JJEngine.scene.World;

public class Target extends GameObject {
	private double xMouseFirstClick,yMouseFirstClick;
	private boolean isMouseStateSame = true;
	private GameObject follow = null;
	private Point glide = new Point(0,0,0);
	private float glideSpeed = 0.1f;
	public Target(Point position, World world) {
		super(position);
		world.add(this);
	}

	public Target(Point point) {
		super(point);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tick() {
		/*
		if(follow == null){
			if(Engine.getMouseDown()&&isMouseStateSame){
				isMouseStateSame=false;
				xMouseFirstClick=Engine.getMouseX()+position.x*Engine.getZoom();
				yMouseFirstClick=Engine.getMouseY()+position.y*Engine.getZoom();
			}
			if(Engine.getMouseDown()){
				position.x=(xMouseFirstClick-Engine.getMouseX())/Engine.getZoom();
				position.y=(yMouseFirstClick-Engine.getMouseY())/Engine.getZoom();
			}
			if(!Engine.getMouseDown()&&!isMouseStateSame){
				isMouseStateSame=true;
			}
		} else {
			position = follow.position;
		}
		*/
	}
	public void setPosition(Point p){
		position = p;
	}
}