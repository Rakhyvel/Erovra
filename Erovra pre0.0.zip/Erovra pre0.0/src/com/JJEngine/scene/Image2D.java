package com.JJEngine.scene;

import java.awt.Color;
import java.awt.image.BufferedImage;

import com.JJEngine.gui.Align;
import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;

public class Image2D extends Model2D {

	int[] pixels;
	float opacity = 1f;
	float bright = 1f;

	public Image2D(int[] temp) {
		super();
		this.pixels = temp;
	}

	public Image2D(int[] temp, Point position, double width, double height, Align align) {
		super(position, width, height, Color.black, true, align);
		this.pixels = temp;
	}

	public Image2D(int[] temp, Point position, double width, double height, Align align, World world) {
		super(position, width, height, Color.black, true, align);
		this.pixels = temp;
		world.add(this);
	}

	public Image2D(int[] temp, GameObject master, double width, double height, Color c, Align align) {
		super(master, width, height, c, true, Align.object);
		this.pixels = temp;
	}

	public Image2D(int[] temp, Model2D model) {
		super(model);
		this.pixels = temp;
	}

	public void render() {
		if (master != null) position = master.position;
		if (visible && onScreen(align, position.x, position.y)) {
			// g2d.drawImage(image, Align.getX(position.x - width / 2, align),
			// Align.getY(position.y + height / 2, align), Align.zoom(width,
			// align), Align.zoom(height, align), null);
			Engine.getRender().drawImage(Align.getX(position.x - width / 2, align), Align.getY(position.y + height / 2, align), (int) width, pixels, opacity);
		}
	}

	public void tick() {}

	public void setOpacity(float o) {
		opacity = o;
	}

	public float getOpacity() {
		return opacity;
	}
	public void setBrightness(float o) {
		bright = o;
	}

	public float getBrightness() {
		return bright;
	}
	
	public void setPixels(int[] temp){
		pixels = temp;
	}
	public void setPixel(int x, int y, int value){
		pixels[(int)(width * y) + x] = value;
	}

}
