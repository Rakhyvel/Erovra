package com.JJEngine.scene;

import java.util.ArrayList;

import com.JJEngine.objects.PhysObject;
import com.JJEngine.objects.Vector;

public class Physics {

	public ArrayList<PhysObject> planets = new ArrayList<PhysObject>();
	public ArrayList<PhysObject> motion = new ArrayList<PhysObject>();
	public ArrayList<PhysObject> sphereCollision = new ArrayList<PhysObject>();
	public ArrayList<PhysObject> AABBCollision = new ArrayList<PhysObject>();

	public void sphereCollision(PhysObject obj) {
		for (int i = 0; i < sphereCollision.size(); i++) {
			if (!sphereCollision.get(i).equals(obj)) {
				double xDif = obj.getX() - sphereCollision.get(i).getX();
				double yDif = obj.getY() - sphereCollision.get(i).getY();
				double zDif = obj.getZ() - sphereCollision.get(i).getZ();
				double distanceSquared = xDif * xDif + yDif * yDif + zDif * zDif;
				boolean collision = distanceSquared < (obj.radius + sphereCollision.get(i).radius) * (obj.radius + sphereCollision.get(i).radius);
				if (collision) {
					obj.collision(obj, sphereCollision.get(i));
					System.out.println("gri");
				}
			}
		}
	}

	public void AABBCollision(PhysObject obj) {
		for (int i = 0; i < AABBCollision.size(); i++) {
			if (!AABBCollision.get(i).equals(obj)) {
				PhysObject obj2 = AABBCollision.get(i);
				if ((obj.getX() + obj.width / 2) >= (obj2.getX() - obj2.width / 2) && (obj2.getX() + obj2.width / 2) >= (obj.getX() - obj.width / 2) && (obj.getY() + obj.height / 2) >= (obj2.getY() - obj2.height / 2) && (obj2.getY() + obj2.height / 2) >= (obj.getY() - obj.height / 2)) {
					obj.collision(obj, AABBCollision.get(i));
				}
			}
		}
	}

	public void motion(double t) {
		PhysObject obj;

		for (int i = 0; i < motion.size(); i++) {
			obj = motion.get(i);
			obj.forces.add(obj.velocity.mult(-obj.muK));

			obj.acceleration = obj.netForces().div(obj.mass);
			obj.velocity = obj.velocity.add(obj.acceleration.mult(t));
			obj.setPosition(obj.getPosition().add(obj.velocity.mult(t)));
			obj.forces.clear();
		}
	}

	public void orbital() {
		// obj is the first planet, obj2 is the second
		PhysObject obj;
		for (int i = 0; i < planets.size(); i++) {
			PhysObject obj2;
			obj = planets.get(i);
			// Go through every planet in the list of planets
			for (int i2 = 0; i2 < planets.size(); i2++) {
				// Go through every planet in the list of planets again
				obj2 = planets.get(i2);
				if (!obj2.equals(obj)) {
					if (obj2.name != ("Trail")) {
						// If the first planet is not the second planet
						double xDif = obj.getX() - obj2.getX();
						double yDif = obj.getY() - obj2.getY();
						double d = Math.sqrt(xDif * xDif + yDif * yDif);
						// F=G*(M*m)/d^2
						double f = 0.45 * ((obj.mass * obj2.mass) / Math.pow(d, 2));
						Vector force = new Vector();
						// Fx = F*dx/d
						// Fy = F*dy/d
						force.x += (f * (xDif) / d);
						force.y += (f * (yDif) / d);
						obj.forces.add(force);
					}
				}
			}
		}
	}

	public void applyMotion(PhysObject obj) {
		if (!motion.contains(obj)) motion.add(obj);
	}

	public void applyOrbit(PhysObject obj) {
		if (!planets.contains(obj)) planets.add(obj);
	}

	public void applySphereCollision(PhysObject obj) {
		if (!sphereCollision.contains(obj)) sphereCollision.add(obj);
	}

	public void applyAABBCollision(PhysObject obj) {
		if (!AABBCollision.contains(obj)) AABBCollision.add(obj);
	}

	public void remove(PhysObject obj) {
		motion.remove(obj);
		planets.remove(obj);
		sphereCollision.remove(obj);
		AABBCollision.remove(obj);
	}

	public void physTick(double t) {
		motion(t / 16666666.666666666);
		orbital();
	}
}
