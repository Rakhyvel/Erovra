package com.JJEngine.scene;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.JJEngine.gui.Align;
import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.PhysObject;
import com.JJEngine.objects.Point;

public class Rect2D extends Model2D {
	float opacity;
	public Rect2D() {
		super();
	}

	public Rect2D(Point position, double width, double height, Color c, boolean full, Align align, World world) {
		super(position, width, height, c, full, align);
		world.add(this);
		opacity = 1f;
	}

	public Rect2D(Point position, double width, double height, Color c, boolean full, Align align) {
		super(position, width, height, c, full, align);
		opacity = 1f;
	}

	public Rect2D(GameObject master, double width, double height, Color c, boolean full) {
		super(master, width, height, c, full, Align.object);
		opacity = 1f;
	}

	public Rect2D(GameObject master, double width, double height, Color c, boolean full, Align align, World world) {
		super(master, width, height, c, full, align);
		world.add(this);
		opacity = 1f;
	}

	public Rect2D(Model2D model) {
		super(model);
		opacity = 1f;
	}

	public Rect2D(Model2D model, World world) {
		super(model);
		world.add(this);
		opacity = 1f;
	}

	public Rect2D(PhysObject master, Color c, boolean full) {
		super(master, master.width, master.height, c, full, Align.object);
		opacity = 1f;
	}

	public Rect2D(PhysObject master, Color c, boolean full, World world) {
		super(master, master.width, master.height, c, full, Align.object);
		world.add(this);
		opacity = 1f;
	}

	public Rect2D(PhysObject master, Color c, boolean full, Align align, World world) {
		super(master, master.width, master.height, c, full, align);
		world.add(this);
		opacity = 1f;
	}

	public void render() {
		if (visible) {
			if (full) {
				if (master == null) {
				//	g2d.fillRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align));
					Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align), c.getRGB(), opacity);
				} else {
					//g2d.fillRect(Align.getX(master.getX() - width / 2, align), Align.getY(master.getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align));
					Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align), c.getRGB(), opacity);
					
				}
			} else {
				if (master == null) {
					Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align), c.getRGB(), opacity);
				} else {
					Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align), c.getRGB(), opacity);
				}
			}
		}
	}

	public void tick() {}
	public void setOpacity(float o){
		opacity = o;
	}
	
	public float getOpacity(){
		return opacity;
	}
}
