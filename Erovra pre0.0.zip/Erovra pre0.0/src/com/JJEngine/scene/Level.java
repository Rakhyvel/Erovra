package com.JJEngine.scene;

import java.awt.Color;
import java.awt.image.BufferedImage;

import com.JJEngine.main.Engine;

import custom.Main;

public class Level {
	public int[][] tiles;
	public boolean[][] mask = new boolean[108][3];
	int width;
	int height;

	public Level(BufferedImage image) {
		width = image.getWidth();
		height = image.getHeight();
		tiles = new int[width * height][3];
		mask = new boolean[width * height][3];
		for (int i = 0; i < width * height; i++) {
			int y = (int) (i / width);
			int x = i - y * width;
			Color color = new Color(image.getRGB(x, y), true);
			tiles[i][0] = color.getBlue();
			tiles[i][1] = color.getGreen();
			tiles[i][2] = color.getRed();
		}
	}

	public int getTile(int x, int y, int z) {
		if( z < -1 || z > 2 || y < 0 || y > 63 || x < 0 || x > 63){
			return 0;
		}
		return tiles[y * width + x][z];
	}

	public int getTile(int i, int z) {
		return tiles[i][z];
	}

	public void setTile(int x, int y, int z, int code) {
		if( z < -1 || z > 2 || y < 0 || y > 63 || x < 0 || x > 63){
			return;
		}
		tiles[y * width + x][z] = code;
	}

	public boolean getMask(int x, int y, int z) {
		if (x < 0 || x > 9 || y < 0 || y - z > 8) {
			return false;
		}
		if (z <= Engine.getWorld(3).getTarget().position.z) {
			return true;
		}
		double xDif = x - 3;
		double yDif = (y - z) - 4;
		double distanceSquared = xDif * xDif + yDif * yDif;
		if (distanceSquared < Math.pow(4, 2)) {
			return false;
		}
		return true;
	}
	
	public float getMaskOpacity(double x, double y, double z){
		if (z <= Engine.getWorld(3).getTarget().position.z) {
			return 1f;
		}
		double xDif = x - Engine.getWorld(3).getTargetX() / 64;
		double yDif = (y + z) - Engine.getWorld(3).getTargetY() / 64;
		float distanceSquared = (float)(Math.pow(xDif * xDif+yDif*yDif,2))/160f;
		if (distanceSquared < 1f) {
			return distanceSquared;
		}
		return 1f;
	}

	public boolean touchingIdBottom(int x, int y, int z, int id) {
		if(getTile((int) (x) / 64, (int) (y) / 64, z) == 4|| getTile((int) (x + 64) / 64, (int) (y) / 64, z)==4){
			return false;
		}
		return getTile((int) (x) / 64, (int) (y) / 64, z) < id || getTile((int) (x + 64) / 64, (int) (y) / 64, z) < id;
	}

	public boolean touchingIdTop(int x, int y, int z, int id) {
		if(getTile((int) (x) / 64, (int) (y+ 64) / 64, z) == 4|| getTile((int) (x + 64) / 64, (int) (y + 64) / 64, z) == 4){
			return false;
		}
		return getTile((int) (x) / 64, (int) (y + 64) / 64, z) < id || getTile((int) (x + 64) / 64, (int) (y + 64) / 64, z) < id;
	}

	public boolean touchingIdLeft(int x, int y, int z, int id) {
		if(getTile((int) (x) / 64, (int) (y) / 64, z) == 4|| getTile((int) (x) / 64, (int) (y + 64) / 64, z) == 4){
			return false;
		}
		return getTile((int) (x) / 64, (int) (y) / 64, z) < id || getTile((int) (x) / 64, (int) (y + 64) / 64, z) < id;
	}

	public boolean touchingIdRight(int x, int y, int z, int id) {
		if(getTile((int) (x + 64) / 64, (int) (y) / 64, z) == 4|| getTile((int) (x + 64) / 64, (int) (y + 64) / 64, z) == 4){
			return false;
		}
		return getTile((int) (x + 64) / 64, (int) (y) / 64, z) < id || getTile((int) (x + 64) / 64, (int) (y + 64) / 64, z) < id;
	}
}
