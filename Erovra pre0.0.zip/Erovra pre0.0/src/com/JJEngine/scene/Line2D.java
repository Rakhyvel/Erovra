package com.JJEngine.scene;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.JJEngine.gui.Align;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;

public class Line2D extends Model2D{
	Point position2;
	GameObject master2;
	
	public Line2D(Point position2){
		super();
		this.position2 = position2;
	}
	public Line2D(GameObject master2){
		super();
		this.master2 = master2;
	}
	public Line2D(Point position, Point position2,Color c, Align align){
		super(position,0,0,c,false, align);
		this.position2 = position2;
	}
	public Line2D(Point position, GameObject master2, Color c, Align align){
		super(position,0,0,c,false, align);
		this.master2 = master2;
	}
	public Line2D(GameObject master, Point position2, Color c, Align align){
		super(master,0,0,c,false,Align.object);
		this.position2 = position2;
	}
	public Line2D(GameObject master, GameObject master2, Color c, Align align){
		super(master,0,0,c,false,Align.object);
		this.master2 = master2;
	}
	public Line2D(Point position2, Model2D model, Align align){
		super(model);
		this.position2 = position2;
		this.align = align;
	}
	public Line2D(GameObject master2, Model2D model, Align align){
		super(model);
		this.master2 = master2;
		this.align = align;
	}
	public void render() {
	/*
		Graphics2D g2d = image.createGraphics();
		g2d.setColor(c);
		if (visible) {
			if (master == null) {
				if (master2 == null){
					g2d.drawLine(Align.getX(position.x, align), Align.getY(position.y, align),Align.getX(position2.x, align), Align.getY(position2.y, align));
				} else {
					g2d.drawLine(Align.getX(position.x, align), Align.getY(position.y, align),Align.getX(0, master2),Align.getY(0, master2));
				}
			} else {
				if (master2 == null){
					g2d.drawLine(Align.getX(0, master), Align.getY(0, master), Align.getX(position2.x, align), Align.getY(position2.y, align));
				} else {
					g2d.drawLine(Align.getX(0, master),Align.getY(0, master), Align.getX(0, master2), Align.getY(0, master2));
				}
			}
		}

	    g2d.dispose();
	    */
	}

	public void tick() {}
}
