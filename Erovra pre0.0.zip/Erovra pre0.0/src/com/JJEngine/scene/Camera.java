package com.JJEngine.scene;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.Point;
import com.JJEngine.objects.Vector;

public class Camera {
	public Point eye;
	public double distance;
	public Point lookat;
	public Vector u,v,w;
	//orthonormal basis
	public Camera(Point eye, Point lookat,double fov){
		this.eye = new Point(eye);
		this.lookat = new Point(lookat);
		this.distance = Engine.getHeight()/2/Math.tan(Math.toRadians(fov));
	}
	public void compute(){
		w = eye.subVec(lookat);
		w.normalize();
		Vector up = new Vector(0.0014,1,0.015);
		
		u=up.cross(w);
		u.normalize();
		
		v=w.cross(u);
		v.normalize();
	}
}
