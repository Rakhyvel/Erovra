package com.JJEngine.scene;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.JJEngine.gui.Align;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;

public class Oval2D extends Model2D {

	public boolean touchingMouse = false;

	public Oval2D() {
		super();
	}

	public Oval2D(Point position, double width, double height, Color c, boolean full, Align align) {
		super(position, width, height, c, full, align);
	}

	public Oval2D(GameObject master, double width, double height, Color c, boolean full) {
		super(master, width, height, c, full, Align.object);
	}

	public Oval2D(GameObject master, double width, double height, Color c, boolean full, Align align) {
		super(master, width, height, c, full, align);
	}

	public Oval2D(Point position, double width, double height, Color c, boolean full, Align align, World world) {
		super(position, width, height, c, full, align);
		world.add(this);
	}

	public Oval2D(GameObject master, double width, double height, Color c, boolean full, World world) {
		super(master, width, height, c, full, Align.object);
		world.add(this);
	}

	public Oval2D(GameObject master, double width, double height, Color c, boolean full, Align align, World world) {
		super(master, width, height, c, full, align);
		world.add(this);
	}

	public Oval2D(Model2D model) {
		super(model);
	}

	public void render() {
		/*if (master != null) position = master.position;
		if (visible && onScreen(align, position.x, position.y)) {
			if (full) {
				g2d.fillOval(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align));
			} else {
				g2d.drawOval(Align.getX(master.getX() - width / 2, align), Align.getY(master.getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align));
			}
		}
		*/
	}

	public void setColor(Color c) {
		this.c = c;
	}

	public void tick() {};
}
