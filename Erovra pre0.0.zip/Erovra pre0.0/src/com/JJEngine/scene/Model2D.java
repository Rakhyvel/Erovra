package com.JJEngine.scene;

import java.awt.Color;
import java.awt.image.BufferedImage;

import com.JJEngine.gui.Align;
import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;

public abstract class Model2D extends GameObject {

	public double height, width;
	public GameObject master;
	public Color c;
	public boolean full;
	public boolean visible;
	public boolean touchingMouse;
	public Align align = Align.raw;

	public Model2D() {
		super(new Point(0, 0, 0));
		this.width = 100;
		this.height = 100;
		this.master = null;
		this.c = new Color(255, 255, 255);
		this.visible = true;
		this.full = true;
	}

	public Model2D(Point position, double width, double height, Color c, boolean full, Align align) {
		super(position);
		this.width = width;
		this.height = height;
		this.master = null;
		this.c = c;
		this.visible = true;
		this.full = full;
		this.align = align;
	}

	public Model2D(GameObject master, double width, double height, Color c, boolean full, Align align) {
		super(new Point(0, 0, 0));
		this.width = width;
		this.height = height;
		this.master = master;
		this.c = c;
		this.visible = true;
		this.full = full;
		this.align = align;
	}

	public Model2D(Model2D model) {
		super(model.position);
		this.width = model.width;
		this.height = model.height;
		this.c = model.c;
		this.full = model.full;
		this.visible = model.visible;
		this.align = model.align;
	}

	public abstract void render();

	public boolean touchingMouse() {
		if (master != null) {
			double xDif = master.getX() - Engine.centerToRawX(Engine.getMouseX());
			double yDif = master.getY() - Engine.centerToRawY(Engine.getMouseY());
			double distanceSquared = xDif * xDif + yDif * yDif;
			boolean collision = Math.sqrt(distanceSquared) < width / 2;
			if (collision) {
				touchingMouse = true;
			} else {
				touchingMouse = false;
			}
		} else {
			double xDif = position.x - Engine.centerToRawX(Engine.getMouseX());
			double yDif = position.y - Engine.centerToRawY(Engine.getMouseY());
			double distanceSquared = xDif * xDif + yDif * yDif;
			boolean collision = Math.sqrt(distanceSquared) < width / 2;
			if (collision) {
				touchingMouse = true;
			} else {
				touchingMouse = false;
			}
		}
		return touchingMouse;
	}

	public boolean touchingMouseAABB() {
		if(Engine.getMouseX() > 0 && Engine.getMouseX() < Engine.getWidth() && Engine.getMouseY() > 0 && Engine.getMouseY() < Engine.getHeight()){
			if (master != null) {
				touchingMouse = false;
				if ((master.position.x + width / 2) > Align.getX(Engine.getMouseX() - Engine.getWidth(), align) && (master.position.x - width / 2) < Align.getX(Engine.getMouseX() - Engine.getWidth(), align)) {
					if ((master.position.y+ height / 2) > Align.getY(Engine.getMouseY(), align) && (master.position.y - height / 2) < Align.getY(Engine.getMouseY(), align)) {
						touchingMouse = true;
					}
				}
			} else {
				touchingMouse = false;
				if ((position.x + width / 2) > Align.getX(Engine.getMouseX() - Engine.getWidth(), align) && (position.x - width / 2) < Align.getX(Engine.getMouseX() - Engine.getWidth(), align)) {
					if ((position.y + height / 2) > Align.getY(Engine.getMouseY(), align) && (position.y - height / 2) < Align.getY(Engine.getMouseY(), align)) {
						touchingMouse = true;
					}
				}
			}
		} else {
			return false;
		}
		return touchingMouse;
	}
	
	public boolean touchingMouseSpherical(int f) {
		double xDif = master.getX() - Engine.centerToRawX(Engine.getMouseX());
		double yDif = master.getY() - Engine.centerToRawY(Engine.getMouseY());
		double distanceSquared = xDif * xDif + yDif * yDif;
		boolean collision = Math.sqrt(distanceSquared) < ((width / 2 - f));
		if (collision) {
			touchingMouse = true;
		} else {
			touchingMouse = false;
		}
		return touchingMouse;
	}

	public boolean onScreen(Align align, double x, double y) {
		boolean onScreen = false;
		double x1 = Align.getX(x - width / 2, align);
		double y1 = Align.getY(y - height / 2, align);
		if (x1 <= Engine.getWidth() && x1 >= -Align.zoom(width, align)) {
			if (y1 <= Engine.getHeight()+Align.zoom(height, align) && y1 >= 0) {
				onScreen = true;
			}
		}
		return onScreen;
	}

	public abstract void tick();
}
