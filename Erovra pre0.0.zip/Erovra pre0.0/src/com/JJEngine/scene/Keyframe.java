package com.JJEngine.scene;

public class Keyframe {
	int startTick;
	int endTick;
	public Keyframe(int startTick, int endTick){
		this.startTick = startTick;
		this.endTick = endTick;
	}
	public float getLinearPercentage(int currentTick){
		float duration = endTick - startTick;
		float elapsed = currentTick-startTick;
		if(elapsed < 0){
			return 0f;
		}
		if(elapsed > 1){
			return 1f;
		}
		return (float) ((float) elapsed / (float) duration);
	}
}
