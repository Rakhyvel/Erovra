package com.JJEngine.scene;

import java.awt.Color;
import java.util.ArrayList;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;

public class World {

	private ArrayList<Model3D> objects3D;
	private ArrayList<Model2D> objects2D;
	private ArrayList<GameObject> gameObjects = new ArrayList<GameObject>();
	private Color background;
	private Physics physics = new Physics();
	private GameObject target;
	private boolean running = false;

	public World() {
		objects3D = new ArrayList<Model3D>();
		objects2D = new ArrayList<Model2D>();
	}

	public void add(Model3D model3D) {
		if (!objects3D.contains(model3D)) objects3D.add(model3D);
	}

	public void add(Model2D model2D) {
		if (!objects2D.contains(model2D)) objects2D.add(model2D);
	}

	public void add(GameObject gameObject) {
		if (!gameObjects.contains(gameObject)) gameObjects.add(gameObject);
	}

	public void remove(Model3D model3D) {
		if (objects3D.contains(model3D)) objects3D.remove(model3D);
	}

	public void remove(Model2D model2D) {
		if (objects2D.contains(model2D)) objects2D.remove(model2D);
	}

	public void remove(GameObject gameObject) {
		if (gameObjects.contains(gameObject)) gameObjects.remove(gameObject);
	}
	public void purge(){
		gameObjects.clear();
		objects2D.clear();
		objects3D.clear();
	}
	public void objTick(double t) {
		physics.physTick(t);
		for (int i = 0; i < gameObjects.size(); i++) {
			gameObjects.get(i).tick();
		}
		for (int i = 0; i < objects2D.size(); i++) {
			if(objects2D != null)
				objects2D.get(i).tick();
		}
	}

	public void start() {
		running = true;
		Engine.setCurrentWorld(this);
	}

	public void stop() {
		running = false;
	}

	public void setTarget(GameObject obj) {
		target = obj;
	}

	public GameObject getTarget() {
		return target;
	}

	public double getTargetX() {
		return target.getX();
	}

	public double getTargetY() {
		return target.getY();
	}

	public ArrayList<Model2D> getObject2D() {
		return objects2D;
	}

	public ArrayList<Model3D> getObject3D() {
		return objects3D;
	}

	public ArrayList<GameObject> getGameObject() {
		return gameObjects;
	}

	public Physics getPhysics() {
		return physics;
	}

	public Color getBackground() {
		return background;
	}
	
	public void setBackground(Color color) {
		this.background = color;
	}

	public boolean getRunning() {
		return running;
	}
}
