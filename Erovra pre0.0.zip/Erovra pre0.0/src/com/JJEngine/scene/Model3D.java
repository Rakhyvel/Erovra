package com.JJEngine.scene;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.JJEngine.Geometry.Tri;
import com.JJEngine.objects.Point;
import com.JJEngine.objects.Vector;

public class Model3D {
	public ArrayList<Tri> faces;
	public Point pos = new Point();
	public double pitch, roll, yaw;
	public Vector scale = new Vector();
	public Model3D(String path){
		faces = new ArrayList<Tri>();
		String status="TRI";
		try {
			// FileReader reads text files in the default encoding.
			FileReader fileReader = new FileReader(path);

			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			while (bufferedReader.ready()) {
				String line = bufferedReader.readLine();
				if(!line.startsWith("//")){
					if(line.equals("TRI")){
						status = line;
					}
					if(line.equals("OBJ")){
						status = line;
					}
					if(line.equals("END")){
						return;
					}
					
					if(status!=line){
						if(status.equals("TRI")){
							double[] pos = new double[12];
							int prevPos=0;
							int commaPos=0;
							for(int i = 0; i<12;i++){
								//first loop is for each coordinate
								boolean found = false;
								for(int i2 = prevPos+1; !found; i2++){
									//second loop is for each didget
									if(line.substring(i2, i2 + 1).equals(",")||line.substring(i2, i2 + 1).equals(";")){
										commaPos=i2;
										found = true;
									}
								}
								pos[i]=Double.parseDouble(line.substring(prevPos+1, commaPos));
								prevPos=commaPos;
							}
							faces.add(new Tri(new Point(pos[0],pos[1],pos[2]),new Point(pos[3],pos[4],pos[5]), new Point(pos[6],pos[7],pos[8]), (pos[9]),(pos[10]),(pos[11])));
							
						}
						if(status.equals("OBJ")){
							double[] pos = new double[9];
							int prevPos=0;
							int commaPos=0;
							for(int i = 0; i<9;i++){
								//first loop is for each coordinate
								boolean found = false;
								for(int i2 = prevPos+1; !found; i2++){
									//second loop is for each didget
									if(line.substring(i2, i2 + 1).equals(",")||line.substring(i2, i2 + 1).equals(";")){
										commaPos=i2;
										found = true;
									}
								}
								pos[i]=Double.parseDouble(line.substring(prevPos+1, commaPos));
								prevPos=commaPos;
							}
							this.pos.x=pos[0];
							System.out.println(pos[0]);
							this.pos.y=pos[1];
							this.pos.z=pos[2];
							
							this.pitch=pos[3];
							this.roll=pos[4];
							this.yaw=pos[5];
							
							this.scale.x=pos[6];
							this.scale.y=pos[7];
							this.scale.z=pos[8];
						}
					}
				}
				bufferedReader.close();
			}
		} catch (FileNotFoundException ex) {
			System.out.println("Could not find file at '" + path + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + path + "'");
		}
	}
	public Model3D(Point pos, double pitch, double roll, double yaw, double scaleX, double scaleY, double scaleZ, ArrayList<Tri> faces){
		this.pos=pos;
		this.pitch=pitch;
		this.roll=roll;
		this.yaw=yaw;
		this.scale.x=scaleX;
		this.scale.y=scaleY;
		this.scale.z=scaleZ;
		this.faces=faces;
	}
}
