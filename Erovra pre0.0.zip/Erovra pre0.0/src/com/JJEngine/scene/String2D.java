package com.JJEngine.scene;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;

import com.JJEngine.fileIO.SpriteSheet;
import com.JJEngine.gui.Align;
import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;

import custom.Main;

public class String2D extends Model2D{
	public String label;
	public String fontFamily;
	public int style;
	public int size;
    FontMetrics metrics;
    float opacity;
    SpriteSheet font;
	public String2D(String label){
		super();
		this.label = label;
	}
	public String2D(String label, World world){
		super();
		this.label = label;
		world.add(this);
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	public String2D(String label,Point position, Color c, Align align){
		super(position,0,0,c,false,align);
		this.label = label;
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	public String2D(String label,Point position, Color c, SpriteSheet font, int size, Align align){
		super(position,0,0,c,false,align);
		this.label = label;
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		this.size = size;
		opacity = 1f;
		this.font = font;
	}
	public String2D(String label,Point position, Color c,  Align align, World world){
		super(position,0,0,c,false,align);
		this.label = label;
		world.add(this);
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	
	public String2D(String label,GameObject master, Color c){
		super(master,0,0,c,false,Align.object);
		this.label = label;
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	public String2D(String label,GameObject master, Color c,World world){
		super(master,0,0,c,false,Align.object);
		this.label = label;
		world.add(this);
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	public String2D(String label,GameObject master, Color c,Align align,World world){
		super(master,0,0,c,false,align);
		this.label = label;
		world.add(this);
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	public String2D(Model2D model,String label){
		super(model);
		this.label = label;
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	public String2D(Model2D model,String label, World world){
		super(model);
		this.label = label;
		world.add(this);
		fontFamily = "Helvetica";
		style = Font.PLAIN;
		size = 16;
		opacity = 1f;
	}
	
	@Override
	public void render() {
		int carriage = 0;
		for(int i = 0; i < label.length(); i++){
			int letter = (int)label.charAt(i);
			if(letter != 13){
				if(align == Align.center){
					Engine.getRender().drawImage(Align.getX((int)(position.x-1 - ((label.length()*((size/16)*11))/2.0) + size) + (i*((size/16)*11)), align), Align.getY((int)position.y+7+carriage,align), size, font.getSubset(letter % 16, letter / 16, size), opacity,c.getRGB());
				} else {	
					Engine.getRender().drawImage(Align.getX((int)(position.x) + (i*((size/16)*11)), align), Align.getY((int)position.y+7+carriage,align), size, font.getSubset(letter % 16, letter / 16, size), opacity,c.getRGB());
				}
			} else {
				carriage+=size;
			}
		}
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}
	public void setOpacity(float o){
		opacity = o;
	}
	
	public float getOpacity(){
		return opacity;
	}

}
