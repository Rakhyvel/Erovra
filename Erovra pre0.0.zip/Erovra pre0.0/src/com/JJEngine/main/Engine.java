package com.JJEngine.main;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

import com.JJEngine.fileIO.Files;
import com.JJEngine.fileIO.Images;
import com.JJEngine.gui.Align;
import com.JJEngine.input.Keyboard;
import com.JJEngine.input.Mouse;
import com.JJEngine.input.MouseWheel;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Vector;
import com.JJEngine.output.Render2D;
import com.JJEngine.output.Render3D;
import com.JJEngine.output.Sound;
import com.JJEngine.output.Window;
import com.JJEngine.scene.Model2D;
import com.JJEngine.scene.Model3D;
import com.JJEngine.scene.Physics;
import com.JJEngine.scene.World;

public class Engine {

	/*
	 * Welcome to Joseph's Java Engine!
	 */

	private static boolean GAME_RUNNING = false;

	private static MainStructure game;

	// Input
	private static final Mouse mouse = new Mouse();
	private static final MouseWheel mouseWheel = new MouseWheel();
	private static final Keyboard keyboard = new Keyboard();

	// Output
	private static Window window;
	private static Render2D render;
	private static Render3D render3D;

	private static final Sound sound = new Sound();

	// I/O
	public static final Files files = new Files();
	public static final Images images = new Images();

	public static final Random rand = new Random();

	public static int ticks = 0;
	private static World currentWorld;

	public static void start(MainStructure main) {
		game = main;
		render = new Render2D();
		render3D = new Render3D(60.0);
		System.out.println("Engine started");
		setGameRunning(true);
		game.init();
		gameLoop();
	}

	public static void stop() {
		GAME_RUNNING = false;
		System.exit(1);
	}

	private static void gameLoop() {
		window = new Window();
		// This gets the time of when the loop started
		double previous = System.nanoTime();
		double lag = 0.0;
		double dt = (1 / game.UPDATESPERSECOND) * 1000000000;
		while (GAME_RUNNING) {
			/*
			 * Find time of iteration, reset 'previous' after finding, increment
			 * 'lag' based on how much time has passed
			 */
			double current = System.nanoTime();
			double elapsed = current - previous;
			previous = current;
			lag += elapsed;
			while (lag >= (dt)) {
				lag -= (dt);
				currentWorld.objTick(dt);
				ticks++;
				render.render();
			}
		}
	}

	public static World getCurrentWorld() {
		return currentWorld;
	}

	public static void setCurrentWorld(World world) {
		if (world != null) {
			currentWorld = world;
		} else {
			System.err.println("Error: Attempted to set Engine.currentWorld to null. Operation aborted");
		}
	}

	public static World getWorld(int i) {
		return game.worlds.get(i);
	}

	public static boolean getGameRunning() {
		return GAME_RUNNING;
	}

	public static void setGameRunning(boolean gameRunning) {
		GAME_RUNNING = gameRunning;
	}

	public static int getWidth() {
		return game.X;
	}

	public static int getHeight() {
		return game.Y;
	}

	public static boolean getBorders() {
		return game.BORDERS;
	}

	public static String getName() {
		return game.NAME;
	}

	public static boolean getResizeable() {
		return game.RESIZABLE;
	}
	
	public static Vector getGravity(){
		return game.gravity;
	}

	public static void buttonAction(String label) {
		game.buttonAction(label);
	}

	public static void mouseWheelUp() {
		game.mouseWheelUp();
	}

	public static void mouseWheelDown() {
		game.mouseWheelDown();
	}

	public static boolean getRefresh() {
		return game.REFRESH;
	}

	public static int getMouseX() {
		return mouse.getX();
	}

	public static int getMouseY() {
		return mouse.getY();
	}

	public static boolean getMouseLeftDown() {
		return mouse.getMouseLeftDown();
	}
	public static boolean getMouseRightDown() {
		return mouse.getMouseRightDown();
	}

	public static Mouse getMouse() {
		return mouse;
	}

	public static MouseWheel getMouseWheel() {
		return mouseWheel;
	}

	public static Keyboard getKeyboard() {
		return keyboard;
	}

	public static int getFrameX() {
		return window.getFrameX();
	}

	public static int getFrameY() {
		return window.getFrameY();
	}

	public static double getZoom() {
		return render.getZoom();
	}

	public static void setZoom(double zoom) {
		render.setZoom(zoom);
	}

	public static double getXOffset() {
		return render.getXOffset();
	}

	public static double getYOffset() {
		return render.getXOffset();
	}

	public static double centerToRawX(double x) {
		return  (Align.getX(x, Align.center)+(getZoom() * getCurrentWorld().getTargetX())-Engine.getWidth()) / getZoom();
	}

	public static double centerToRawY(double y) {
		return (Align.getY(y, Align.center) + (getZoom() * getCurrentWorld().getTargetY())) / getZoom();
	}

	public static double rawToCenterX(double x) {
		return Align.getX(getZoom() * x, Align.center) - (getZoom() * getCurrentWorld().getTargetX());
	}

	public static double rawToCenterY(double y) {
		return Align.getY(getZoom() * y, Align.center) + (getZoom() * getCurrentWorld().getTargetY());
	}

	public static Render2D getRender() {
		return render;
	}

	public static void render3D(BufferedImage buffer) {
		render3D.render3d(buffer);
	}

	public static Sound getSound() {
		return sound;
	}

	public static Files getFiles() {
		return files;
	}

	public static Images getImages() {
		return images;
	}

	public static Random getRand() {
		return rand;
	}

	public static Color blackbody(double x) {
		if(x > 100){
			return new Color(0,0,255);
		}
		
		double i = 0.102 * (x * x);
		double i2 = 0.102 * (x - 100) * (x - 100);
		double v1 = 0.0000408 * (x * x * x * x);
		double v2 = 0.0000408 * (x - 100) * (x - 100) * (x - 100) * (x - 100);
		double r = 0, g = 0, b = 0;
		if (x < 50) {
			r = 255;
			g = i;
			b = v1;
		} else {
			r = v2;
			g = i2;
			b = 200;
		}
		return new Color((int)r, (int)g, (int)b);
	}
	public static double blackbodyRed(double x) {
		double i = 0.102 * (x * x);
		double i2 = 0.102 * (x - 100) * (x - 100);
		double v1 = 0.0000408 * (x * x * x * x);
		double v2 = 0.0000408 * (x - 100) * (x - 100) * (x - 100) * (x - 100);
		double r = 0, g = 0, b = 0;
		if (x < 50) {
			r = 255;
			g = i;
			b = v1;
		} else {
			r = v2;
			g = i2;
			b = 255;
		}
		if(r > 255)
			r = 255;
		return r;
	}
	public static double blackbodyGreen(double x) {
		double i = 0.102 * (x * x);
		double i2 = 0.102 * (x - 100) * (x - 100);
		double v1 = 0.0000408 * (x * x * x * x);
		double v2 = 0.0000408 * (x - 100) * (x - 100) * (x - 100) * (x - 100);
		double r = 0, g = 0, b = 0;
		if (x < 50) {
			r = 255;
			g = i;
			b = v1;
		} else {
			r = v2;
			g = i2;
			b = 255;
		}
		if(g > 255)
			g = 255;

		return g;
	}
	public static double blackbodyBlue(double x) {
		double i = 0.102 * (x * x);
		double i2 = 0.102 * (x - 100) * (x - 100);
		double v1 = 0.0000408 * (x * x * x * x);
		double v2 = 0.0000408 * (x - 100) * (x - 100) * (x - 100) * (x - 100);
		double r = 0, g = 0, b = 0;
		if (x < 50) {
			r = 255;
			g = i;
			b = v1;
		} else {
			r = v2;
			g = i2;
			b = 255;
		}
		if(b > 255)
			b = 255;
		return b;
	}

	public static Physics getCurrentPhysics() {
		return currentWorld.getPhysics();
	}

	public static Physics getWorldPhysics(int i) {
		return game.worlds.get(i).getPhysics();
	}

	public static ArrayList<Model2D> getCurrentObjects2D() {
		return currentWorld.getObject2D();
	}

	public static ArrayList<Model2D> getWorldObjects2D(int i) {
		return game.worlds.get(i).getObject2D();
	}

	public static Model2D getWorldObjects2D(int i, int j) {
		return game.worlds.get(i).getObject2D().get(j);
	}

	public static ArrayList<Model3D> getCurrentObjects3D() {
		return currentWorld.getObject3D();
	}

	public static ArrayList<Model3D> getWorldObjects3D(int i) {
		return game.worlds.get(i).getObject3D();
	}

	public static Model3D getWorldObjects3D(int i, int j) {
		return game.worlds.get(i).getObject3D().get(j);
	}

	public static ArrayList<GameObject> getCurrentGameObjects() {
		return currentWorld.getGameObject();
	}

	public static ArrayList<GameObject> getCurrentGameObjects(int i) {
		return game.worlds.get(i).getGameObject();
	}

	public static GameObject getWorldGameObjects(int i, int j) {
		return game.worlds.get(i).getGameObject().get(j);
	}
	public static String randName(int length){
		String name = "";
		double r;
		for(int i = 0; i<length; i++){
			r = Engine.rand.nextDouble();
			if(r < .5){
				if(i == 0){
					String tempName = findConsonant().toUpperCase();
					if(tempName == "'" || tempName == " " || tempName == "-"){
						tempName = "T";
					}
					name = name + tempName;
				}else{
					name = name + findConsonant();
				}
					name = name + findVowel();
			}
			if(r > 0.5 && r < 0.75){
				if(i == 0){
					String tempName = findConsonant().toUpperCase();
					if(tempName == "'" || tempName == " " || tempName == "-"){
						tempName = "T";
					}
					name = name + tempName;
				}else{
					name = name + findConsonant();
				}
				name = name + findVowel();
				
				if(i == length-1){
					String tempName = findConsonant();
					if(tempName == "'" || tempName == " " || tempName == "-"){
						tempName = "r";
					}
					name = name + tempName;
				}else{
					name = name + findConsonant();
				}
			}
			if(r > 0.75){
				if(i == 0){
					name = name + findVowel().toUpperCase();
				}else{
					name = name + findVowel();
				}
				if(i == length-1){
					String tempName = findConsonant();
					if(tempName == "'" || tempName == " " || tempName == "'"){
						tempName = "n";
					}
					name = name + tempName;
				}else{
					name = name + findConsonant();
				}
			}
		}
		return name;
	}
	public static String findConsonant(){
		String[] consonant = new String[]{     "t",  "n",  "r",  "s",  "d",  "l",  "m",  "g",  "k",  "h",  "v",  " ", "f",  "c",  "-",  "p",  "'", "b",  "j", "y",  "x",  "z",  "q"};
		double[] consonantWeight = new double[]{8.89, 7.88, 7.88, 5.32, 4.9,  4.81, 3.55, 3.44, 3.24, 2.85, 2.55, 2.1, 1.81, 1.71, 1.66, 1.57, 1.5, 1.31, 0.9, 0.49, 0.11, 0.04, 0.01};
		// 1/rank = proabability
		// Imagine chosing a random angle on a pie chart with different segmentsItem[] items = ...;

		// Compute the total weight of all items together
		double totalWeight = 0.0d;
		for (int i = 0; i<consonantWeight.length;i++)
		{
		    totalWeight += consonantWeight[i];
		}
		// Now choose a random item
		int randomIndex = -1;
		double random = Math.random() * totalWeight;
		for (int i = 0; i < consonant.length; ++i)
		{
		    random -= consonantWeight[i];
		    if (random <= 0.0d)
		    {
		        randomIndex = i;
		        break;
		    }
		}
		return consonant[randomIndex];
	}	
	public static String findVowel(){
		String[] consonant = new String[]{     "a", "e",  "i", "o", "u"};
		double[] consonantWeight = new double[]{10.04,9.85,5.01,4.06,1.86};
		// 1/rank = proabability
		// Imagine chosing a random angle on a pie chart with different segmentsItem[] items = ...;

		// Compute the total weight of all items together
		double totalWeight = 0.0d;
		for (int i = 0; i<consonantWeight.length;i++)
		{
		    totalWeight += consonantWeight[i];
		}
		// Now choose a random item
		int randomIndex = -1;
		double random = Math.random() * totalWeight;
		for (int i = 0; i < consonant.length; ++i)
		{
		    random -= consonantWeight[i];
		    if (random <= 0.0d)
		    {
		        randomIndex = i;
		        break;
		    }
		}
		return consonant[randomIndex];
	}
}
