package com.JJEngine.main;

import java.util.ArrayList;

import com.JJEngine.objects.Point;
import com.JJEngine.objects.Target;
import com.JJEngine.objects.Vector;
import com.JJEngine.scene.World;

public abstract class MainStructure {

	public World world;
	public int X;
	public int Y;
	public String NAME;
	public boolean RESIZABLE = false;
	public boolean BORDERS = true;
	public boolean REFRESH = true;
	public double UPDATESPERSECOND = 30;
	public double colorCurve = 1;
	public Point tint = new Point(0, 0, 0);
	public Vector gravity = new Vector(0,0,-.001);
	public final ArrayList<World> worlds = new ArrayList<World>();

	public abstract void init();

	public abstract void buttonAction(String name);

	public abstract void mouseWheelUp();

	public abstract void mouseWheelDown();

	public void setup() {
		world = new World();
		world.setTarget(new Target(new Point(0, 0, 0), world));
		worlds.add(world);
	}

	public void setSize(int x, int y) {
		this.X = x;
		this.Y = y;
	}

	public void setName(String name) {
		this.NAME = name;
	}
}
