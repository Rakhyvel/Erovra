package com.JJEngine.gui;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;

public enum Align {
	raw(0), center(1), top(2), bottom(3), left(4), right(5), topLeft(6), topRight(7), bottomLeft(8), bottomRight(9), object(10), mouse(11), target(12);
	int id = 0;

	Align(int id) {
		this.id = id;
	}
	
	public static int getX(double x, Align align){
		switch (align.id){
		case 0: case 4: case 6: case 8:
			// Raw, left, top-left, bottom-left. Do nothing.
			x = x-(Engine.getWidth()/2);
			break;
		case 1: case 2: case 3:
			// Center, top, bottom. Shift X value to center of screen
			x = x+(Engine.getWidth()/2);
			break;
		case 5: case 7: case 9:
			// Right, top-right, bottom-right. Shift x to other side of screen, inverse
			x = (Engine.getWidth())-x;
			break;
		case 10:
			System.err.println("Error: Object alignment cannot be used in this context. Change to getX(x, GameObject). Raw alignment used instead. X: " + x);
			break;
		case 11:
			x = x+(Engine.getMouseX());
			break;
		case 12:
			x = Engine.rawToCenterX(x);
			break;
		default:
			System.err.println("Error: Unknown or unsupported alignment given. Raw alignment used instead");
			break;
		}
		return (int) x;
	}
	public static int getX(Align align, float percent){
		if(align.id == 10){
			System.err.println("Error: Proportional object alignment cannot be used. Raw propotional alignment used instead");
			return getX(percent * (Engine.getWidth()), raw);
		}
		return getX(percent * (Engine.getWidth()), align);
	}
	public static int getX(double x, GameObject obj){
		if(obj == null){
			System.err.println("Error: GameObject is null. Raw alignment used instead");
			return (int) x;
		}
		return getX((x+obj.getX()), Align.center);
	}
	public static int getY(double y, Align align){
		switch (align.id){
		case 0: case 2: case 6: case 7:
			//Raw, top, top-left, top-right. Do nothing.
			break;
		case 1: case 4: case 5:
			// Center, left, right. Shift down to center, inverse.
			y = (Engine.getHeight()/2)-y;
			break;
		case 3: case 8: case 9:
			// Bottom, bottom-left, bottom-right. Shift full window, inverse
			y = (Engine.getHeight())-y;
			break;
		case 10:
			System.err.println("Error: Object alignment cannot be used in this context. Change to getY(y, GameObject). Raw alignment used instead. Y: " + y);
			break;
		case 11:
			y = y+(Engine.getMouseY());
			break;
		case 12:
			y = Engine.rawToCenterY(y);
			break;
		default:
			System.err.println("Error: Unknown or unsupported alignment given. Raw alignment used instead");
			break;
		}
		if(Engine.getBorders())
			return (int) y-22;
		return (int) y;
	}
	public static int getY(Align align, float percent){
		if(align.id == 10){
			System.err.println("Error: Proportional object alignment cannot be used. Raw propotional alignment used instead");
			return getY(percent * (Engine.getHeight()), raw);
		}
		return getY(percent * (Engine.getHeight()), align);
	}
	public static int getY(double y, GameObject obj){
		if(obj == null){
			System.err.println("Error: GameObject is null. Raw alignment used instead");
			return (int) y;
		}
		return getY((y-obj.getY()), Align.center);
	}
	public static int zoom(double size, Align align){
		if (align.id == 12){
			return (int)(size*Engine.getZoom());
		}
		return (int) size;
	}
}