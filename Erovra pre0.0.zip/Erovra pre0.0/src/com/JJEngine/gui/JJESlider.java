package com.JJEngine.gui;

import java.awt.Color;
import java.awt.image.BufferedImage;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;
import com.JJEngine.scene.Model2D;

public class JJESlider extends Model2D {
	float opacity;
	float value;

	public JJESlider(Point position, double width, double height, Color lineColor, float value, Align align) {
		super(position, width, height, lineColor, true, align);
		this.value = value;
		opacity = 1f;
	}

	public JJESlider(GameObject master, double width, double height, Color lineColor, float value, Align align) {
		super(master, width, height, lineColor, true, Align.object);
		this.value = value;
		opacity = 1f;
	}

	public JJESlider(Color lineColor,float value, Model2D model) {
		super(model);
		this.value = value;
		opacity = 1f;
	}

	public void render() {
		Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY(), align), Align.zoom(width, align), Align.zoom(1, align), c.getRGB(), opacity);
		Engine.getRender().drawRect(Align.getX(getX() - ((width / 2) * ((value*-2)+1)) - ((height / 3.125) / 2), align), Align.getY(getY() + (height / 3.125) / 2, align), Align.zoom(height / 3.125, align), Align.zoom(height / 3.125, align), c.getRGB(), opacity);
	}

	public void tick() {
		if(Engine.getMouseLeftDown() && touchingMouseAABB()){
			value = (float)((Align.getX(Engine.getMouseX(),Align.raw) - getX()-(width/2)) / width) + 1f;
		}
		if(value <= 0.03 && value != 0){
			value = 0;
		}
		if(value >= 0.97 && value != 1){
			value = 1;
		}
	}
	
	public float getValue(){
		return value;
	}
	
	public void setValue(float v){
		value = v;
	}

	public void setOpacity(float o){
		opacity = o;
	}
	
	public float getOpacity(){
		return opacity;
	}
}
