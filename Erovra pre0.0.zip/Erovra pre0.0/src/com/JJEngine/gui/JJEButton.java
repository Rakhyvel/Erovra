package com.JJEngine.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;
import com.JJEngine.scene.Model2D;

import custom.Main;

public class JJEButton extends Model2D{
	public String label;
	public String label2;
	Color textColor;
	Color hoverColor;
	Color disabledColor;
	Color disabledTextColor;
	Color hoverTextColor;
	Color defaultColor;
	Color defaultTextColor;
	int size = 18;
	Font font;
    FontMetrics metrics;
    float opacity;
	private boolean clicked;
	private boolean hovered;
	private boolean enabled = true;
	
	public JJEButton(String label, Color textColor){
		super();
		this.label = label;
		label2 = label;
		this.defaultTextColor = textColor;
		this.textColor = textColor;
		this.defaultColor = c;
		this.hoverTextColor = textColor.brighter();
		this.hoverColor = c.brighter();
		size = 16;
		font =  new Font("helvetica", Font.PLAIN, size);
		opacity = 1f;
	}
	public JJEButton(String label, Color textColor,Point position, double width, double height, Color c, boolean full, Align align){
		super(position,width,height,c,full,align);
		this.label = label;
		label2 = label;
		this.defaultTextColor = textColor;
		this.textColor = textColor;
		this.defaultColor = c;
		this.hoverTextColor = textColor.brighter();
		this.hoverColor = c.brighter();
		size = 16;
		font =  new Font("helvetica", Font.PLAIN, size);
		opacity = 1f;
	}
	public JJEButton(String label, Color textColor,Point position, double width, double height, Color c, Color hoverColor, Color disabled, Color disabledText, boolean full, Align align){
		super(position,width,height,c,full,align);
		this.label = label;
		label2 = label;
		this.defaultTextColor = textColor;
		this.textColor = textColor;
		this.defaultColor = c;
		this.hoverTextColor = textColor.brighter();
		this.hoverColor = hoverColor;
		this.disabledColor = disabled;
		this.disabledTextColor = disabledText;
		size = 16;
		font =  new Font("helvetica", Font.PLAIN, size);
		opacity = 1f;
	}
	public JJEButton(String label, Color textColor,GameObject master, double width, double height, Color c, boolean full){
		super(master,width,height,c,full,Align.object);
		this.label = label;
		label2 = label;
		this.defaultTextColor = textColor;
		this.textColor = textColor;
		this.defaultColor = c;
		this.hoverTextColor = textColor.brighter();
		this.hoverColor = c.brighter();
		size = 16;
		font =  new Font("helvetica", Font.PLAIN, size);
		opacity = 1f;
	}
	public JJEButton(String label, Color textColor,Model2D model){
		super(model);
		this.label = label;
		label2 = label;
		this.defaultTextColor = textColor;
		this.textColor = textColor;
		this.defaultColor = c;
		this.hoverTextColor = textColor.brighter();
		this.hoverColor = c.brighter();
		size = 16;
		font =  new Font("helvetica", Font.PLAIN, size);
		opacity = 1f;
	}
	public void render() {
		if (visible) {
			if (master == null) {
				Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align), c.getRGB(), opacity);
			} else {
				Engine.getRender().drawRect(Align.getX(master.getX() - width / 2, align), Align.getY(master.getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align),c.getRGB(), opacity);
			}
			for(int i = 0; i < label.length(); i++){
				int letter = (int)label.charAt(i);
				//Engine.getRender().drawImage(Align.getX((int)(position.x - ((label.length()*16.0)/2.0) + 16.0) + (i*16), align), Align.getY((int)position.y+6,align), 16, Main.font.getSubset(letter & 15, letter / 16, 16), opacity,textColor.getRGB());
			}
		}
	}

	public void tick() {
		if(enabled){
			if(touchingMouseAABB() && opacity > .9f){
				if(!hovered && !clicked){
					hovered = true;
					Engine.getSound().play("sound/hover");
				}
				textColor = hoverTextColor;
				c = hoverColor;
					
				if(Engine.getMouseLeftDown()){
					if(!clicked){
						clicked = true;
						Engine.getSound().play("sound/click");
						Engine.buttonAction(label2);
					}
				} else {
						clicked = false;
				}
			} else {
				hovered = false;
				textColor = defaultTextColor;
				c = defaultColor;
			}
		} else {
			textColor = disabledTextColor;
			c = disabledColor;
			if(touchingMouseAABB() && opacity > .9f){
				if(Engine.getMouseLeftDown()){
					if(!clicked){
						clicked = true;
						if(!hoverColor.equals(defaultColor))
							Engine.getSound().play("sound/err");
					}
				} else {
					clicked = false;
				} 
			}
		}
	}
	public void setOpacity(float o){
		opacity = o;
	}
	
	public float getOpacity(){
		return opacity;
	}
	public void enable(){
		enabled = true;
	}
	public void disable(){
		enabled = false;
	}
}
