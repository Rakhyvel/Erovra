package com.JJEngine.gui;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;
import com.JJEngine.scene.Model2D;

import custom.Main;

public class JJEFileChooser extends Model2D {

	private Color background;
	private Color foreground;
	private Color textColor;
	private Color highlightedTextColor;
	private Color highlighted;
	private Color cText;
	File directory;
	float opacity;
	File[] listOfFiles;
	int hover;
	int selected;
	double scrollOffset;

	public JJEFileChooser(File file, Point position, double width, double height, Color background, Color foreground, Color textColor, Color highlightedColor, Color highText, Align align) {
		super(position, width, height, background, true, align);
		this.background = background;
		this.textColor = textColor;
		this.foreground = foreground;
		this.highlighted = highlightedColor;
		this.highlightedTextColor = highText;
		this.directory = file;
		listOfFiles = directory.listFiles();
		opacity = 1f;
		selected = -1;
		scrollOffset = 0;
	}

	public JJEFileChooser(File file, GameObject master, double width, double height, Color background, Color foreground, Color textColor, Color highlightedColor, Color highText, Align align) {
		super(master, width, height, background, true, Align.object);
		this.background = background;
		this.textColor = textColor;
		this.foreground = foreground;
		this.highlighted = highlightedColor;
		this.highlightedTextColor = highText;
		this.directory = file;
		listOfFiles = directory.listFiles();
		opacity = 1f;
		selected = -1;
		scrollOffset = 0;
	}

	public JJEFileChooser(File file, Color background, Color foreground, Color textColor, Color highlightedColor, Color highText, Model2D model) {
		super(model);
		this.background = background;
		this.textColor = textColor;
		this.foreground = foreground;
		this.highlighted = highlightedColor;
		this.highlightedTextColor = highText;
		this.directory = file;
		listOfFiles = directory.listFiles();
		opacity = 1f;
		selected = -1;
		scrollOffset = 0;
	}

	@Override
	public void render() {

		if(listOfFiles.length * 50 > 300){
			Engine.getRender().drawRect(Align.getX(getX() + (width /2) -25, align), Align.getY(getY() + height / 2 - 34, align), Align.zoom(22, align), Align.zoom(300, align), background.getRGB(), opacity);
			Engine.getRender().drawRect(Align.getX(getX() + (width /2) -25, align), Align.getY(getY() + height / 2 - 34 - 300*(scrollOffset/(listOfFiles.length*50 - 300)), align), Align.zoom(22, align), Align.zoom(3, align), textColor.getRGB(), opacity);
		}
		
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				// System.out.println("File " + listOfFiles[i].getName());
				if (i == hover && hover <= listOfFiles.length) {
					c = background;
					cText = textColor;
				} else {
					c = foreground;
					cText = textColor;
				}

				if (i == selected) {
					c = highlighted;
					cText = highlightedTextColor;
				}

				Engine.getRender().drawRect(Align.getX(getX() - (width - 6) / 2, align), Align.getY(getY() + height / 2 - i * 50 - 34 + scrollOffset, align), Align.zoom(width - 28, align), Align.zoom(50, align), c.getRGB(), opacity);
				
				String label = listOfFiles[i].getName();
				for (int i2 = 0; i2 < label.length(); i2++) {
					int letter = (int) label.charAt(i2);
					//Engine.getRender().drawImage(Align.getX((int) (getX()) + (i2 * 11) - (width - 100) / 2, align), Align.getY((int) position.y + 6 - i * 50 - 25 + 158 + scrollOffset, align), 16, Main.font.getSubset(letter & 15, letter / 16, 16), opacity, cText.getRGB());
				}
			}
		}
	}

	@Override
	public void tick() {
		if (Align.getX(Engine.getMouseX(), Align.raw) < getX() + (width / 2) - 24 && Align.getX(Engine.getMouseX(), Align.raw) > getX() - (width / 2)) {
			if (opacity >= .9) {
				if (Engine.getMouseLeftDown()) {
					if (Engine.getMouseY() < 360 || Engine.getMouseY() > 459) {
						if (selected != hover) {
							if (selected >= 0 && selected < listOfFiles.length || hover >= 0 && hover < listOfFiles.length) {
								Engine.getSound().play("sound/click");
								selected = hover;
							}
						}
					}
				}
				if (hover != (int) ((Engine.getMouseY() + scrollOffset) / 50) - 1 && (int) ((Engine.getMouseY() + scrollOffset) / 50) - 1 >= 0 && (int) ((Engine.getMouseY() + scrollOffset) / 50) - 1 < listOfFiles.length) {
					Engine.getSound().play("sound/hover");
				}
				hover = (int) ((Engine.getMouseY() + scrollOffset) / 50) - 1;
			}
		} else {
			if (Engine.getMouseLeftDown()) {
				if (selected != -1) {
					Engine.getSound().play("sound/click");
					selected = -1;
				}
			}
			hover = -1;
		}
		if (opacity >= .9) {
			if(scrollOffset >= 0){
				if(listOfFiles.length * 50 > 300){
					if(scrollOffset < listOfFiles.length*50 - 300){
						scrollOffset = Engine.getZoom() - 1;
					} else {
						scrollOffset = listOfFiles.length*50 - 301;
						Engine.setZoom(listOfFiles.length*50 - 301);
					}
				}
			} else {
				scrollOffset = 0;
				Engine.setZoom(1);
			}
		}
	}

	public void setOpacity(float o) {
		opacity = o;
	}

	public float getOpacity() {
		return opacity;
	}

	public File getSelected() {
		if (selected != -1 && selected < listOfFiles.length) {
			return listOfFiles[selected];
		}
		return null;
	}

	public void refresh() {
		listOfFiles = directory.listFiles();
		scrollOffset = 0;
	}

	public File[] getFiles() {
		return listOfFiles;
	}
}
