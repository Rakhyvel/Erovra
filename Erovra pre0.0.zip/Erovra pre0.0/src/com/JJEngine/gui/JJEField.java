package com.JJEngine.gui;

import java.awt.Color;
import java.awt.image.BufferedImage;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;
import com.JJEngine.scene.Model2D;
import com.JJEngine.scene.World;

import custom.Main;


public class JJEField extends Model2D{
	float opacity = 1f;
	Color defaultColor;
	Color textColor;
	Color enabledColor;
	Color errColor;
	boolean hovered;
	boolean clicked;
	boolean enabled;
	String pastLetter = "";
	String label = "";
	int limit;
	int errTick = -1;

	public JJEField(Point position, double width, double height, Color background, Color textColor, Color enabledColor, int limit,Align align){
		super(position,width,height,background,true,align);
		defaultColor = background;
		this.textColor = textColor;
		this.enabledColor = enabledColor;
		this.limit = limit;
	}
	public JJEField(GameObject master, double width, double height, Color background, Color textColor,Color enabledColor,int limit,Align align, World world){
		super(master,width,height,background,true,Align.object);
		defaultColor = background;
		this.textColor = textColor;
		this.enabledColor = enabledColor;
		this.limit = limit;
	}
	public JJEField(Color background, Color textColor,Color enabledColor,int limit,Model2D model){
		super(model);
		defaultColor = background;
		this.textColor = textColor;
		this.enabledColor = enabledColor;
		this.limit = limit;
	}
	public void render() {
		if (visible) {
			if (master == null) {
				Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align), c.getRGB(), opacity);
				//Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() - height / 2, align), Align.zoom(width, align), Align.zoom(1, align), Main.black.getRGB(), opacity);
				
			} else {
				Engine.getRender().drawRect(Align.getX(master.getX() - width / 2, align), Align.getY(master.getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align),c.getRGB(), opacity);
			}
			for(int i = 0; i < label.length(); i++){
				int letter = (int)label.charAt(i);
				//Engine.getRender().drawImage(Align.getX((int)(position.x - ((label.length()*16.0)/2.0) + 16.0) + (i*16), align), Align.getY((int)position.y+6,align), 16, Main.font.getSubset(letter & 15, letter / 16, 16), opacity,textColor.getRGB());
			}
		}
	}

	@Override
	public void tick() {
		if(enabled){
			if(errTick > Engine.ticks-5){
				c = errColor;
			} else {
				c = enabledColor;
			}
			
			String letter = Engine.getKeyboard().getLetter();
			if(!letter.equals(pastLetter)){
				if(letter != "" && (int)letter.charAt(0) < 65535){
					if((int)letter.charAt(0) == 8 && label.length() > 0){
						label = label.substring(0, label.length()-1);
						Engine.getSound().play("sound/hover");
					} else {
						if((int)letter.charAt(0)!= 27 && (int)letter.charAt(0)!= 8){
							if(label.length() < limit){
								label = label + letter;
								Engine.getSound().play("sound/hover");
							} else {
								Engine.getSound().play("sound/err");
								errTick = Engine.ticks;
							}
						} else {
							enabled = false;
							Engine.getSound().play("sound/click");
						}
					}
				}
				pastLetter = letter;
			}
		} else {
			c = defaultColor;
		}
		
		if(Engine.getMouseLeftDown()){
			if(touchingMouseAABB()){
				if(!enabled){
					enabled = true;
					Engine.getSound().play("sound/click");
				}
			} else {
				if(enabled){
					enabled = false;
					Engine.getSound().play("sound/click");
				}
			}
		}
	}
	public void setOpacity(float o){
		opacity = o;
	}
	
	public float getOpacity(){
		return opacity;
	}
	public String getLabel(){
		return label;
	}
}
