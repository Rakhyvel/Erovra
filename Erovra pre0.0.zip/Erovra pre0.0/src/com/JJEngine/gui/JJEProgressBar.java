package com.JJEngine.gui;

import java.awt.Color;
import java.awt.image.BufferedImage;

import com.JJEngine.main.Engine;
import com.JJEngine.objects.GameObject;
import com.JJEngine.objects.Point;
import com.JJEngine.scene.Model2D;
import com.JJEngine.scene.World;


public class JJEProgressBar extends Model2D{
	float progress = 0.0f;
	float opacity = 1f;
	Color fullColor = new Color(255,255,255);

	public JJEProgressBar(float progress,Point position, double width, double height, Color emptyColor, Color fullColor, Align align){
		super(position,width,height,emptyColor,true,align);
		this.progress=progress;
		this.fullColor=fullColor;
	}
	public JJEProgressBar(float progress, GameObject master, double width, double height, Color emptyColor, Color fullColor, Align align, World world){
		super(master,width,height,emptyColor,true,Align.object);
		this.progress=progress;
		this.fullColor=fullColor;
	}
	public JJEProgressBar(float progress, Color fullColor,Model2D model){
		super(model);
		this.progress=progress;
		this.fullColor=fullColor;
	}
	public void render() {
		if (visible) {
			if (master == null) {
				Engine.getRender().drawRect(Align.getX(getX() - width / 2, align), Align.getY(getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align), c.getRGB(), opacity);
				Engine.getRender().drawRect(Align.getX(getX() - width/2, align), Align.getY(getY() + height / 2, align), Align.zoom(width*progress, align), Align.zoom(height, align), fullColor.getRGB(), opacity);
				} else {
				Engine.getRender().drawRect(Align.getX(master.getX() - width / 2, align), Align.getY(master.getY() + height / 2, align), Align.zoom(width, align), Align.zoom(height, align),c.getRGB(), opacity);
			}
		}
	}

	@Override
	public void tick() {
	}
	public void setProgress(float f){
		this.progress = f;
	}
	public float getProgress(){
		return progress;
	}
	public void setOpacity(float o){
		opacity = o;
	}
	
	public float getOpacity(){
		return opacity;
	}
}
